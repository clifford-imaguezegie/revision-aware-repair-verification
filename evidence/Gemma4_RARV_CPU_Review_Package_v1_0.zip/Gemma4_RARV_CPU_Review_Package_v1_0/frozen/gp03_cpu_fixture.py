"""Two definitions lifted verbatim from the GP03 paired CPU acceptance notebook."""

from pathlib import Path
import sys
import tempfile
import time

from gp03_public_runtime import (CPUHold, PAIR_BUDGET, WorkspaceFingerprinter,
    attach_gp03_pair, canonical_hash, prepare_pytest_config, run_git,
    visible_definition_binding, visible_definition_paths, write_json)


class CPUPairToolContext:
    """Scripted tool calls. The trusted adapter still runs actual public pytest."""

    def __init__(self, root):
        self.root = root
        self.forwarded_submissions = 0

    def create_tools(self):
        def run_command(command):
            return {"status": "ok", "exit_code": 0, "scope": "SCRIPTED_CPU_COMMAND_REQUEST"}

        def write_file(filepath, content):
            target = self.root / filepath
            target.write_text(content, encoding="utf-8")
            return {"status": "ok", "filepath": filepath}

        def submit_patch():
            self.forwarded_submissions += 1
            return {"status": "ok", "scope": "SCRIPTED_CPU_GATE_PROBE"}

        return {"run_command": run_command, "edit_file": write_file, "write_file": write_file,
                "submit_patch": submit_patch}


def replay_gp03_fixture(output, environment_sha):
    rows = []
    for arm in ("B", "C"):
        folder = output / arm
        folder.mkdir(parents=True)
        with tempfile.TemporaryDirectory(prefix=f"gp03_control_{arm}_", dir=output.parent) as scratch:
            root = Path(scratch).resolve()
            (root / "src/requests").mkdir(parents=True)
            (root / "tests/certs/ca").mkdir(parents=True)
            (root / "tests/certs/ca/value.txt").write_text("certificate\n")
            (root / "tests/certs/current").symlink_to("ca", target_is_directory=True)
            production = "src/requests/__init__.py"
            (root / production).write_text("VALUE = 1\n")
            selector = "tests/test_gp03_contract.py"
            (root / selector).write_text(
                "from pathlib import Path\nfrom requests import VALUE\n\n"
                "def test_value_and_link():\n"
                "    assert VALUE == 1\n"
                "    assert Path('tests/certs/current/value.txt').read_text() == 'certificate\\n'\n",
            )
            (root / "tests/pytest.ini").write_text("[pytest]\n")
            prepare_pytest_config(root)
            for args in (["init", "-q"], ["add", "."],
                         ["-c", "user.name=GP03", "-c", "user.email=fixture@example.invalid", "commit", "-qm", "fixture"]):
                run_git(root, args)
            head = run_git(root, ["rev-parse", "HEAD"]).stdout.decode().strip()
            argv = [sys.executable, "-m", "pytest", selector, "-q", "--tb=short"]
            files = visible_definition_paths(root)
            definition_sha, links = visible_definition_binding(root, files)
            check_id = "gp03_control_fixture"
            manifest = {"task_id": "gp03_control_fixture", "repo": "psf/requests", "production_root": "src/requests/",
                        "environment_sha256": environment_sha, "definition_link_targets": links,
                        "baseline_source_sha256": WorkspaceFingerprinter(root).snapshot().sha256,
                        "expected_nodeids": [selector + "::test_value_and_link"],
                        "check": {"check_id": check_id, "command": argv,
                                  "definition_sha256": canonical_hash([argv, definition_sha]), "reserve_seconds": 15.0,
                                  "test_selection": selector, "expected_collected": 1, "definition_files": files,
                                  "definition_files_sha256": definition_sha, "allow_missing_definition_files": True,
                                  "pinned_environment_sha256": environment_sha}}
            context = CPUPairToolContext(root)
            boundary, restore = attach_gp03_pair(
                context=context, root=root, results_root=folder / "checks", manifest=manifest, arm=arm, seed=42,
                run_id=f"cpu_fixture_{arm}", environment_sha=environment_sha,
                started_monotonic=time.monotonic(), baseline_ref=head,
            )
            try:
                tools = context.create_tools()
                controller = boundary.controller
                ledger = controller.ledger
                tools["run_command"](command=f"pytest {selector} -k partial")
                if ledger.receipts:
                    raise CPUHold("COMMAND_SCOPE", "A partial test command must never qualify for a receipt")
                tools["run_command"](command=f"python -m pytest -q {selector}")
                initial = ledger.current_status(check_id)
                tools["write_file"](filepath="repro.py", content="print('scratch')\n")
                scratch_status = ledger.current_status(check_id)
                reply = tools["edit_file"](filepath=production, content="VALUE = 2\n")
                after_edit = ledger.current_status(check_id)
                after_edit_tests = controller.budget.used_test_runs
                tools["submit_patch"]()
                broken = boundary.submission_status
                if context.forwarded_submissions:
                    raise CPUHold("BROKEN_GATE_ACCEPTED", f"{arm} forwarded a broken patch")
                tools["edit_file"](filepath=production, content="VALUE = 1\n")
                tools["submit_patch"]()
                restored = boundary.submission_status
                provenance = [item.provenance for item in ledger.receipts]
                regressions = [event for event in ledger.events if event["type"] == "OBSERVED_PASS_TO_FAIL_AFTER_EDIT"]
                expected_after = "STALE" if arm == "B" else "CURRENT_FAIL"
                expected_tests = 1 if arm == "B" else 2
                expected_provenance = ["agent", "final_gate" if arm == "B" else "controller_recheck", "final_gate"]
                write_json(folder / "Ledger.json", ledger.export())
                write_json(folder / "Tool_Boundary.json", boundary.export_audit())
                failures = [item for item in controller.executor.executions if item["reason"]]
                if failures:
                    raise CPUHold(failures[0]["reason"], failures[0]["detail"])
                if (initial != "CURRENT_PASS" or scratch_status != "CURRENT_PASS" or after_edit != expected_after
                        or after_edit_tests != expected_tests or provenance != expected_provenance
                        or broken != "BLOCKED_VISIBLE_CHECK_FAILED" or restored != "SUBMITTED_GATE_VALID"
                        or len(regressions) != 1 or context.forwarded_submissions != 1
                        or ("gp02c_evidence" in reply) != (arm == "C") or controller.budget.used_model_calls != 0):
                    raise CPUHold("CONTROLLED_REPLAY_HOLD", f"Unexpected {arm} status, feedback, or tool accounting")
                controller.deadline.started_monotonic = time.monotonic() - PAIR_BUDGET["ordinary_seconds"] - 1
                try:
                    tools["run_command"](command=f"pytest {selector}")
                except RuntimeError as exc:
                    if str(exc) != "Absolute repair deadline exhausted":
                        raise
                else:
                    raise CPUHold("ORDINARY_CUTOFF", "An ordinary tool ran during the final reserve")
                if not controller.final_gate().accepted:
                    raise CPUHold("FINAL_RESERVE", "The current pass was unavailable to the gate during its reserve")
                controller.deadline.started_monotonic = time.monotonic() - PAIR_BUDGET["worker_seconds"] - 1
                if controller.final_gate().accepted or controller.budget.used_test_runs != 3:
                    raise CPUHold("OVERALL_CUTOFF", "The gate or a check ran after the worker cap")
                rows.append({"arm": arm, "after_scratch_edit": scratch_status, "after_production_edit": after_edit,
                             "after_edit_trusted_tests": after_edit_tests, "broken_gate": broken, "restored_gate": restored,
                             "test_provenance": provenance, "trusted_tests": controller.budget.used_test_runs})
            finally:
                restore()
        print(f"[fixture {arm}] after edit {after_edit} | broken gate blocked | restored gate accepted", flush=True)
    return rows
