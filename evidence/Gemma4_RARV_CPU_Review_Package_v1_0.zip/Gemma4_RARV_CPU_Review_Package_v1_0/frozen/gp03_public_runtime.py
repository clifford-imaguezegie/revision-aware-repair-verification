from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path, PurePosixPath
from typing import Mapping, Sequence
import ast
import csv
import fcntl
import hashlib
import json
import os
import platform
import posixpath
import re
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import time
import uuid
import xml.etree.ElementTree as ET
import zipfile
from dataclasses import asdict
from typing import Callable

COMPETITION_DIR = Path("/kaggle/input/competitions/gemma-4-developer-agent")
WORK_DIR = Path("/kaggle/working")
CPU_EVIDENCE_ZIP = None  # Set an absolute path only if the original ZIP has been renamed.
AUTO_DOWNLOAD_ZIP = True

from collections.abc import Mapping
import functools
import inspect
import select
import shlex

PUBLIC_ADAPTER_EVIDENCE_ZIP = None  # Set an absolute path only if the original ZIP has been renamed.

GP03_PAIR_RECIPE_SHA256 = 'abac8f45bd12386f79f9059e7b9eb207fe8ae55276788cb494a3cba87de60a27'

ADAPTER_RECIPE_SHA256 = 'ac01106525c4d97767b950cf565de028526f9934e93375e2d6ab981b0863bbca'

ELIGIBLE_POOL_SHA256 = 'cba7da409788164e4f559f74d325088333c033db57b2739adf8b86955d68b541'

GP03_CPU_EVIDENCE = {'cpu_environment_sha256': '0f53e69268c9834ce589f44b8adf8a27263e8daab2ff90f5e37a333ffa34d772',
 'filename': 'GP03_CPU_Qualification_20261108T225859Z_ca48fb6a.zip',
 'gp00_split_sha256': '27b50b7f46c510c55b7b7bb264aba729abba0cc9e53647e596690c94cd79bb09',
 'notebook_recipe_sha256': '0ae4bc06d88271e9b2ccd3c4fcdae182d9b58b07743eb7130cf7daa317a0f750',
 'qualification_run_sha256': '085458dbf8f424ea23dcc57914e4c284c1bcaaf55ac1f8e5c56d678c8717cff9',
 'sha256': '166d33d3e2426c26831b8473c2098ffc6cf990072165d492fe4926784b03cce2',
 'tasks_sha256': 'e4b3fd60f69dbc2b9213e54eeb9636db78aefe92c1d06269d73d9f5f8f3c8ad6'}

GP03_PROPOSED_PAIRS = [{'pair_index': 1,
  'seed': 42,
  'arm_order': ['B', 'C'],
  'task_id': 'fastapi_14964',
  'repo': 'fastapi/fastapi',
  'base_commit': 'bc06e4296d588f39f38c7ac2fc96d3913c565962',
  'snapshot_bytes': 271065089,
  'baseline_outcome': 'PASS',
  'cpu_receipt_origin': 'v1.0_retained',
  'cpu_check_member': 'tasks/fastapi_14964/CPU_Check_Manifest.json',
  'cpu_check_sha256': '30a05a807d13a9cbf8cb03f6a13f8b55e5c0ea8e5b5194654d8fe9507eac743d',
  'cpu_receipt_sha256': 'f5aebd1a3823212bb17b7e06b00ef59ef1f594c8de86f4cc82796a923d06e783',
  'snapshot_sha256': 'f09059d29d925ac0b5ed96ddd8ee164e656cdf164d8ae88a53bae3ff783659e8',
  'native_head': '47da909b715240cfe7dc2b04d2994c56c9153b52',
  'native_tree': 'cac1a745f81c2ac504ce548da1a4106cc53a5e23',
  'public_check_argv': ['/usr/bin/python3',
                        '-m',
                        'pytest',
                        'tests/test_orjson_response_class.py',
                        '-q',
                        '--tb=short'],
  'expected_collected': 1,
  'has_snapshot_links': False,
  'rank_sha256': '0b1c850408e946a63c547c1ae99ce1cfad9505a10ae7ebf51960f3a725266f75'},
 {'pair_index': 2,
  'seed': 42,
  'arm_order': ['C', 'B'],
  'task_id': 'requests_7502',
  'repo': 'psf/requests',
  'base_commit': '661970d171d9c3e12e4c789c4768db647d8c4da0',
  'snapshot_bytes': 37463957,
  'baseline_outcome': 'PASS',
  'cpu_receipt_origin': 'v1.1_retry',
  'cpu_check_member': 'tasks/requests_7502/CPU_Check_Manifest.json',
  'cpu_check_sha256': 'c6a3ae1855099875f96cfa57f9b5f31a0007b6f7699d8ec3aec2fa064dd2a2cc',
  'cpu_receipt_sha256': '93edc64af99aaf183eed4eb79a0198c5b4d646cfd1c57bca0423c72edf2ac57a',
  'snapshot_sha256': 'a7da726a17f54ea4d43d1a21e3e9f3e95bfa2787a845a18e2d30a88fcc1f53fb',
  'native_head': 'ced47d0b985f67110197b488df11f54e4d355eca',
  'native_tree': 'ea72ddd13e602fe8f9d9a5546d1be5f64b46046c',
  'public_check_argv': ['/usr/bin/python3',
                        '-m',
                        'pytest',
                        'tests/test_requests.py::TestRequests::test_basicauth_encodes_byte_strings',
                        '-q',
                        '--tb=short'],
  'expected_collected': 1,
  'has_snapshot_links': True,
  'rank_sha256': '04e9442de4385c144ad4dfa09f1633861723f1211563255f7b9f38956450f8a4'},
 {'pair_index': 3,
  'seed': 42,
  'arm_order': ['B', 'C'],
  'task_id': 'rich_3718',
  'repo': 'Textualize/rich',
  'base_commit': '7d36119f8378b36129502c3281a7faffef837e02',
  'snapshot_bytes': 95464718,
  'baseline_outcome': 'PASS',
  'cpu_receipt_origin': 'v1.1_retry',
  'cpu_check_member': 'tasks/rich_3718/CPU_Check_Manifest.json',
  'cpu_check_sha256': '7fad2c43829f54b41af538bda13a4c1ad54d06c4e18aac0b40df212598734cb1',
  'cpu_receipt_sha256': 'dabf2c77ced00da25bdeceb8a876510e67295d1ec2e7c7c7c1fc730a04e4037c',
  'snapshot_sha256': 'f66ac24cfee77115da4b15dfad5e5adbab07faedb53a62693bf16b75c2750eb6',
  'native_head': 'fef719c6fa6ea0305898a10ca7244b9da200a6cb',
  'native_tree': 'e1652a57c5e0929cc91da1f8333834d9ae898515',
  'public_check_argv': ['/usr/bin/python3', '-m', 'pytest', 'tests/test_panel.py', '-q', '--tb=short'],
  'expected_collected': 11,
  'has_snapshot_links': False,
  'rank_sha256': '2a13e31c5f90e29d0762c259ff078c17571643f6db97b63f6ade61ef1cf500bf'},
 {'pair_index': 4,
  'seed': 42,
  'arm_order': ['C', 'B'],
  'task_id': 'fastapi_12942',
  'repo': 'fastapi/fastapi',
  'base_commit': '27c0f7e75fc0ce26ca75295d455eb36f0ca033d3',
  'snapshot_bytes': 218214164,
  'baseline_outcome': 'PASS',
  'cpu_receipt_origin': 'v1.0_retained',
  'cpu_check_member': 'tasks/fastapi_12942/CPU_Check_Manifest.json',
  'cpu_check_sha256': 'b2ceca01de32d22080a3e5ae9b7f6772bc15d5f3871e0535142870e3e9b8efb8',
  'cpu_receipt_sha256': 'a9f795e8af84f2d11e8bc8d70bc747d5d2166ee8e81747790561dd72cc9e56ab',
  'snapshot_sha256': '68f9786237a6b5cc811190e95f8d45045d850aa09f77cb8be71e6bfd8e900a2a',
  'native_head': '8c426cdec82445a3f69c8af6ae991ab26d10ea80',
  'native_tree': '09e60c5d118d3d01fdcc6fdbb970c4b44ef22451',
  'public_check_argv': ['/usr/bin/python3',
                        '-m',
                        'pytest',
                        'tests/test_response_model_as_return_annotation.py',
                        '-q',
                        '--tb=short'],
  'expected_collected': 38,
  'has_snapshot_links': False,
  'rank_sha256': '0c84af5514ba9d8d279adc9713c0966642d5978893e576561125dcf276821336'},
 {'pair_index': 5,
  'seed': 42,
  'arm_order': ['B', 'C'],
  'task_id': 'requests_7205',
  'repo': 'psf/requests',
  'base_commit': '1b40fdd004bfc8ba5301bcf8a6908264e9b6b877',
  'snapshot_bytes': 37402474,
  'baseline_outcome': 'PASS',
  'cpu_receipt_origin': 'v1.1_retry',
  'cpu_check_member': 'tasks/requests_7205/CPU_Check_Manifest.json',
  'cpu_check_sha256': 'ac5b3accf4b666a01fe937fe459a4146d1f9e0c8fffe9eeee416aba8a293039b',
  'cpu_receipt_sha256': '7285909ade50c8e6533cb3eb87e640a99141b6c7f6db8d04006b5b155bdde251',
  'snapshot_sha256': '42dc3d360f842a5c7a66d0008ac05447fcd807dc33ee8cc18d2f2d4876283106',
  'native_head': '443f0b73558781b7dac0e304ad268a30ee35aaeb',
  'native_tree': '683d44befe0d3519469011c35e46f332eebbc010',
  'public_check_argv': ['/usr/bin/python3',
                        '-m',
                        'pytest',
                        'tests/test_requests.py::TestRequests::test_proxy_auth_empty_pass',
                        '-q',
                        '--tb=short'],
  'expected_collected': 1,
  'has_snapshot_links': True,
  'rank_sha256': '0a3fd9629109362be6725a7ea800d14b08d4904a587634ec0494501afa5aa08c'},
 {'pair_index': 6,
  'seed': 42,
  'arm_order': ['C', 'B'],
  'task_id': 'rich_4077',
  'repo': 'Textualize/rich',
  'base_commit': '58ac15120fe254886c10d6253667733c83604cb4',
  'snapshot_bytes': 97076310,
  'baseline_outcome': 'PASS',
  'cpu_receipt_origin': 'v1.1_retry',
  'cpu_check_member': 'tasks/rich_4077/CPU_Check_Manifest.json',
  'cpu_check_sha256': '202833bc7ea98a1ff967c2480884d15d67bae2adcf682302c58af265f2fde382',
  'cpu_receipt_sha256': '58d6eb45f64a93c28491f55510d6df8b4a4f744d0dbc5571fe80de4d8ee58e8e',
  'snapshot_sha256': '96aab6cf7a51b313a5e203b27c7bc4c557b044eaa65f0120fe0c27357fa6ed4f',
  'native_head': '11cdcf5c9e81f42d4e9b2e3981bc8f67ed44b18e',
  'native_tree': 'bc6ede75faeaee74089fa8f3b91fa5f5e3ac3138',
  'public_check_argv': ['/usr/bin/python3', '-m', 'pytest', 'tests/test_file_proxy.py', '-q', '--tb=short'],
  'expected_collected': 3,
  'has_snapshot_links': False,
  'rank_sha256': '3f0898754663f089d61c6483eda14c56ec4d04eeebda696f098e0b116d1cc39e'},
 {'pair_index': 7,
  'seed': 42,
  'arm_order': ['B', 'C'],
  'task_id': 'fastapi_15023',
  'repo': 'fastapi/fastapi',
  'base_commit': 'c0836dc1b7f4ba91e9563c8c4ccd0ebe655bc914',
  'snapshot_bytes': 275792435,
  'baseline_outcome': 'PASS',
  'cpu_receipt_origin': 'v1.0_retained',
  'cpu_check_member': 'tasks/fastapi_15023/CPU_Check_Manifest.json',
  'cpu_check_sha256': 'a0924d89fb59c4f42653c5d6a52a0a102faf5590ad18cdb322b627f1c907d47b',
  'cpu_receipt_sha256': '67d5a51c6a0800c841c6edf7350fd275aef0311e05ef1bf243a6b124fb264609',
  'snapshot_sha256': 'b3873cfe6c959e13ef6d655648ab1cf4931d096af69debf70550ecfdf4146ccf',
  'native_head': 'f7f72e123b1f425f7aa98a13920a3413856077cf',
  'native_tree': 'e677615e75916874f814d2b2499f6efbb22aa00a',
  'public_check_argv': ['/usr/bin/python3',
                        '-m',
                        'pytest',
                        'tests/test_dependency_after_yield_streaming.py',
                        '-q',
                        '--tb=short'],
  'expected_collected': 7,
  'has_snapshot_links': False,
  'rank_sha256': '1f0a7967c5bceccdcc4f9c8262d571fb6cab317ee2dd029039a33bc8fefc39f9'},
 {'pair_index': 8,
  'seed': 42,
  'arm_order': ['C', 'B'],
  'task_id': 'requests_7427',
  'repo': 'psf/requests',
  'base_commit': 'b684dcb9bbf3aa557d1238e72062c4a29737dd1c',
  'snapshot_bytes': 37176965,
  'baseline_outcome': 'PASS',
  'cpu_receipt_origin': 'v1.1_retry',
  'cpu_check_member': 'tasks/requests_7427/CPU_Check_Manifest.json',
  'cpu_check_sha256': 'fecce775e5605870467133259043c81e60ea0039319ddbd30b2f80860b8a2db8',
  'cpu_receipt_sha256': 'c3017eaa1270aaf077bdedd5e1f256d6ccc486dbc475e84fa38a8397b3528988',
  'snapshot_sha256': 'd8f2092187969feb4f4b32b501682d76c09e27173371b4673c1daceef72f2e04',
  'native_head': '6cd34441464a253437ac6d7846379fd4f945b97b',
  'native_tree': 'f89ba9281369ca35eaad0f27853941e129836be2',
  'public_check_argv': ['/usr/bin/python3',
                        '-m',
                        'pytest',
                        'tests/test_requests.py::TestRequests::test_proxy_authorization_not_appended_to_https_request',
                        '-q',
                        '--tb=short'],
  'expected_collected': 2,
  'has_snapshot_links': True,
  'rank_sha256': '0a4bb2e29eee1a6c909d019abe71822ac222153ad3672536c87c1b9982f364f5'},
 {'pair_index': 9,
  'seed': 42,
  'arm_order': ['B', 'C'],
  'task_id': 'rich_3043',
  'repo': 'Textualize/rich',
  'base_commit': '8a616de8e25db3c93abaaa220c493d80878de69d',
  'snapshot_bytes': 90818810,
  'baseline_outcome': 'PASS',
  'cpu_receipt_origin': 'v1.1_retry',
  'cpu_check_member': 'tasks/rich_3043/CPU_Check_Manifest.json',
  'cpu_check_sha256': 'ec7ff0096a38d1d9999f65c3f6ad0e303597365593e5287b691c514b0c13eba9',
  'cpu_receipt_sha256': '113364c86485926628f62eb4f50fcd7bf753686959218b25da606cf3dd05615b',
  'snapshot_sha256': '71edf847e2907fcde33ce124f6d57871448c8b55aba059cda75bad05b7653d2d',
  'native_head': 'c41239b93ac0e9af2f4e3890dfb807f942b31f89',
  'native_tree': 'c2ab870ce396f066664ea9de5678ee71ca24dd92',
  'public_check_argv': ['/usr/bin/python3',
                        '-m',
                        'pytest',
                        'tests/test_console.py::test_export_html',
                        '-q',
                        '--tb=short'],
  'expected_collected': 1,
  'has_snapshot_links': False,
  'rank_sha256': '4b5b2a65bb1e9464b6570821066d4291aeb6dd7e4be135c3d7ff298317bb869e'}]

GP03_DEVELOPMENT = [
    ('fastapi_15589', 'fastapi/fastapi', '22b02e26f9e8c7e32bd8266e2b0ebe8bb3a0db2b'),
    ('rich_4079', 'Textualize/rich', '19c67b9a3479841e9133bea94607c89ee931d3fc'),
    ('fastapi_14479', 'fastapi/fastapi', '2b212ddd7604891d42e2ffbafe764c334230bdb7'),
    ('fastapi_5624', 'fastapi/fastapi', 'c6487ed632056e450d844846a1b63be551a3cbc6'),
    ('httpx_3672', 'encode/httpx', '4acf5c2c37714cc63b5cf71b3e284fca83c90311'),
    ('requests_6757', 'psf/requests', '0e322af87745eff34caffe4df68456ebc20d9068'),
    ('rich_2943', 'Textualize/rich', '610fd75c433c3dfcd9c296e8b91363979127b9fa'),
    ('rich_3130', 'Textualize/rich', '720800e6930d85ad027b1e9bd0cbb96b5e994ce3'),
]

GP03_ADAPTER_EVIDENCE_NAME = 'GP03_Public_Adapter_Acceptance_20261109T002001Z_1c73a0b4.zip'
GP03_ADAPTER_EVIDENCE_SHA256 = '76a13ad7a352f9fa4b80142d866e3679a234060195a0643b1b71b6ececb61416'

POLICY = {
    "version": "GP03_CPU_Qualification_v1.1",
    "selector_rule": "public_issue_to_tracked_test_paths_and_symbols_v1",
    "max_selectors": 5,
    "large_file_test_functions": 50,
    "max_collected_nodes": 200,
    "snapshot_bytes_expanded_cap": 6 * 1024**3,
    "task_wall_seconds": 300,
    "collect_wall_seconds": 55,
    "baseline_wall_seconds": 40,
    "final_reserve_seconds": 60,
    "optional_import_fallback": [
        "dirty_equals", "email_validator", "httpbin", "inline_snapshot", "multipart", "orjson",
        "pytest_asyncio", "pytest_httpbin", "pytest_mock", "trustme", "ujson", "uvicorn",
    ],
    "optional_fixture_fallback": ["httpbin", "httpbin_secure"],
}

PACKAGE_LAYOUTS = {
    "fastapi/fastapi": ("fastapi", ("fastapi", "src/fastapi")),
    "Textualize/rich": ("rich", ("rich", "src/rich")),
    "psf/requests": ("requests", ("requests", "src/requests")),
}

EXTRA_DEPENDENCIES = (
    "attrs", "brotli", "charset-normalizer", "cryptography", "dirty-equals",
    "flask", "httpbin", "pytest-httpbin", "pytest-mock", "requests-mock",
    "simplejson", "socksio", "trustme", "uvicorn", "werkzeug",
)

OFFLINE_FLAGS = {
    "CUDA_VISIBLE_DEVICES": "",
    "GIT_CONFIG_NOSYSTEM": "1",
    "GIT_CONFIG_GLOBAL": os.devnull,
    "GIT_OPTIONAL_LOCKS": "0",
    "GIT_TERMINAL_PROMPT": "0",
    "HF_HUB_OFFLINE": "1",
    "PIP_CONFIG_FILE": os.devnull,
    "PIP_NO_INDEX": "1",
    "PIP_NO_INPUT": "1",
    "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
    "PYTHONDONTWRITEBYTECODE": "1",
    "PYTHONHASHSEED": "0",
    "PYTHONNOUSERSITE": "1",
    "TRANSFORMERS_OFFLINE": "1",
}

PUBLIC_TEST = re.compile(r"tests/(?:[A-Za-z0-9_-]+/)*[A-Za-z0-9_-]+\.py")

VALID_ID = re.compile(r"[A-Za-z0-9_]+")

GIT_ID = re.compile(r"[0-9a-f]{40}")

class CPUHold(RuntimeError):
    def __init__(self, reason, detail):
        super().__init__(detail)
        self.reason = reason

TEST_DEPENDENCIES = (
    'pytest', 'pluggy', 'iniconfig', 'packaging', 'pytest-asyncio', 'pytest-cov',
    'pytest-timeout', 'coverage', 'typing-extensions', 'pydantic', 'pydantic-core',
    'typing-inspection', 'annotated-types', 'annotated-doc', 'starlette', 'anyio',
    'httpx', 'httpcore', 'h11', 'h2', 'hpack', 'hyperframe', 'idna', 'sniffio',
    'certifi', 'requests', 'urllib3', 'python-multipart', 'email-validator',
    'markdown-it-py', 'mdurl', 'pygments', 'exceptiongroup', 'trio',
    'fastapi-cli', 'jinja2', 'orjson', 'ujson', 'pyyaml',
)

def canonical_hash(obj: object) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=True,
                                      separators=(",", ":"), default=str).encode()).hexdigest()

def environment_fingerprint(config: Mapping[str, object]) -> str:
    """Hash explicit environment identity supplied by the trusted harness.

    In live integration, include installed wheel/source hashes and relevant runtime
    settings, not just package names, and refresh after environment modifications.
    """
    if not config:
        raise ValueError("Nonempty trusted environment manifest required")
    return canonical_hash(dict(config))

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(262144), b""):
            h.update(block)
    return h.hexdigest()

def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    temporary.replace(path)

def _cancel_process_group(proc: subprocess.Popen, grace: float = 0.15) -> None:
    """Terminate a process GROUP even if its leader has already exited.

    A parent exiting after SIGTERM does not prove children have exited. All
    checks run in their own POSIX session. After a brief grace, SIGKILL is sent
    to the *group*, including remaining descendants, even if leader.poll() != None.
    """
    if os.name == "posix":
        pgid = proc.pid  # subprocess.Popen(start_new_session=True)
        try:
            os.killpg(pgid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            proc.wait(timeout=max(grace, 0.02))
        except subprocess.TimeoutExpired:
            pass
        # Crucial: don't return merely because the group LEADER exited.
        # An orphan/daemonized child in this process group may still be alive.
        time.sleep(min(0.04, max(grace, 0.0)))
        try:
            os.killpg(pgid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            pass
    else:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=grace)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=2)

def load_gp03_inputs(competition, candidates, development, release_sha):
    """Use issue text and metadata from the pinned release, with an explicit projection."""
    if not (competition / "tasks.jsonl").is_file():
        raise CPUHold("TASK_RELEASE_MISSING", f"Mount the Developer Agent input at {competition}")
    if not (competition / "snapshots").is_dir():
        raise CPUHold("SNAPSHOT_MOUNT_MISSING", f"Expected {competition / 'snapshots'}")
    if sha256_file(competition / "tasks.jsonl") != release_sha:
        raise CPUHold("TASK_RELEASE_MISMATCH", "tasks.jsonl SHA-256 differs from the GP00 release")
    index = {r["task_id"]: r for r in candidates}
    groups = {(r["repo"], r["base_commit"]) for r in candidates}
    dev_ids = {r[0] for r in development}
    dev_groups = {(r[1], r[2]) for r in development}
    if len(index) != len(candidates) or len(groups) != len(candidates):
        raise CPUHold("COHORT_DUPLICATE", "Candidate IDs and repository/commit groups must be unique")
    if dev_ids.intersection(index) or dev_groups.intersection(groups):
        raise CPUHold("COHORT_OVERLAP", "Candidate set intersects the development set")
    for task, row in index.items():
        if (not VALID_ID.fullmatch(task) or row["repo"] not in PACKAGE_LAYOUTS
                or not GIT_ID.fullmatch(row["base_commit"]) or row["snapshot_bytes"] <= 0):
            raise CPUHold("COHORT_INVALID", f"Invalid public identity for {task}")

    issues = {}
    with (competition / "tasks.jsonl").open(encoding="utf-8") as stream:
        for line in stream:
            if not line.strip():
                continue
            raw = json.loads(line)
            task = raw.get("instance_id")
            if task in index:
                pin = index[task]
                if task in issues or (raw.get("repo"), raw.get("base_commit")) != (
                    pin["repo"], pin["base_commit"]
                ):
                    raise CPUHold("TASK_IDENTITY_MISMATCH", f"Release identity differs for {task}")
                issue = raw.get("problem_statement")
                if not isinstance(issue, str) or not issue.strip():
                    raise CPUHold("PUBLIC_ISSUE_MISSING", f"Public issue description missing for {task}")
                issues[task] = issue
            del raw
    if set(issues) != set(index):
        raise CPUHold("CANDIDATE_MISSING_FROM_RELEASE", "A selected GP00 case is missing")
    return issues

def environment_profile():
    if os.name != "posix" or sys.version_info < (3, 12):
        raise CPUHold("RUNTIME_UNSUPPORTED", "Use the Kaggle Linux CPU image with Python 3.12 or later")
    try:
        import pytest
    except ImportError as exc:
        raise CPUHold("PYTEST_UNAVAILABLE", "Use the organizer CPU image with pytest available") from exc
    if shutil.which("git") is None:
        raise CPUHold("GIT_UNAVAILABLE", "The published snapshots require Git")
    packages = {}
    for name in sorted(set(TEST_DEPENDENCIES) | set(EXTRA_DEPENDENCIES)):
        try:
            dist = metadata.distribution(name)
        except metadata.PackageNotFoundError:
            packages[name] = None
        else:
            record = dist.read_text("RECORD") or dist.read_text("METADATA") or ""
            packages[name] = {"version": dist.version, "record_sha256": hashlib.sha256(record.encode()).hexdigest()}
    return {
        "python_version": platform.python_version(),
        "python_executable": sys.executable,
        "python_executable_sha256": sha256_file(Path(sys.executable).resolve()),
        "machine": platform.machine(),
        "pytest_version": pytest.__version__,
        "test_dependencies": packages,
        "flags": OFFLINE_FLAGS,
    }

def command_env(root, temporary, capture=None, package=None):
    home = temporary / "home"
    home.mkdir(exist_ok=True)
    paths = [root, root / "src"]
    if capture is not None:
        paths.append(temporary)
    env = {
        "PATH": os.environ.get("PATH", os.defpath), "HOME": str(home),
        "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "TZ": "UTC",
        "TMPDIR": str(temporary), "TMP": str(temporary), "TEMP": str(temporary),
        "PYTHONPATH": os.pathsep.join(map(str, paths)), **OFFLINE_FLAGS,
    }
    if capture is not None:
        env.update(GP03_CAPTURE_PATH=str(capture), GP03_PUBLIC_PACKAGE=package)
    return env

def bounded_command(argv, root, env, output, timeout):
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    with (output / "stdout.txt").open("wb") as stdout, (output / "stderr.txt").open("wb") as stderr:
        proc = subprocess.Popen(
            argv, cwd=root, env=env, stdout=stdout, stderr=stderr, start_new_session=True,
        )
        timed_out = False
        try:
            if tuple(argv[1:3]) == ('-m', 'pytest'):
                try:
                    register_trusted_child(proc, os.environ, tuple(argv))
                except (LiveSourceHold, OSError) as exc:
                    raise CPUHold('TRUSTED_PYTEST_REGISTRATION', str(exc)) from exc
            proc.wait(timeout=max(0.01, timeout))
        except subprocess.TimeoutExpired:
            timed_out = True
        finally:
            try:
                os.killpg(proc.pid, 0)
            except ProcessLookupError:
                pass
            else:
                _cancel_process_group(proc)
    return {
        "argv": list(argv), "exit_code": proc.returncode, "timed_out": timed_out,
        "seconds": round(time.monotonic() - started, 3),
    }

def remaining(deadline, phase_cap):
    seconds = deadline - time.monotonic()
    if seconds <= 0:
        raise CPUHold("TASK_DEADLINE", "The CPU task wall clock expired")
    return min(seconds, phase_cap)

EXCLUDED_DIRS = frozenset({
    ".git", ".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", ".tox", ".nox", ".cache", "node_modules", ".ipynb_checkpoints",
    ".gp02c_results", "__ledger_output__", "htmlcov", ".coverage-data",
})

EXCLUDED_NAMES = frozenset({".coverage", ".DS_Store", "coverage.xml"})

EXCLUDED_SUFFIXES = frozenset({".pyc", ".pyo"})

PYTEST_CONFIG_NAMES = (
    "pytest.ini", ".pytest.ini", "pyproject.toml", "setup.cfg", "tox.ini",
    "pytest.toml", ".pytest.toml",
)

RICH_OPTIONAL_TEST_DEFINITIONS = (
    "conftest.py", "tests/conftest.py", "tests/__init__.py",
    *PYTEST_CONFIG_NAMES, *(f"tests/{name}" for name in PYTEST_CONFIG_NAMES),
)

@dataclass(frozen=True)
class Snapshot:
    sha256: str
    files: int
    entries: tuple[tuple[str, str, str], ...]

class WorkspaceFingerprinter:
    """Conservative all-files policy, except a fixed generated-artifact exclusion list.

    Includes untracked source and config; file additions, deletions and symlink
    targets affect the fingerprint. NEVER walk an evaluator/protected workspace.
    """
    def __init__(self, root: str | Path):
        self.root = Path(root).resolve(strict=True)
        if not self.root.is_dir():
            raise ValueError("Workspace root must be a directory")

    def snapshot(self) -> Snapshot:
        entries: list[tuple[str, str, str]] = []
        for base, dirs, files in os.walk(self.root, followlinks=False):
            basedir = Path(base)
            # Symlink directories are recorded as links, never dereferenced.
            for name in list(dirs):
                full = basedir / name
                if name in EXCLUDED_DIRS:
                    dirs.remove(name)
                elif full.is_symlink():
                    dirs.remove(name)
                    rel = full.relative_to(self.root).as_posix()
                    entries.append((rel, "L", hashlib.sha256(os.readlink(full).encode()).hexdigest()))
            for name in files:
                if name in EXCLUDED_NAMES or Path(name).suffix in EXCLUDED_SUFFIXES:
                    continue
                full = basedir / name
                rel = full.relative_to(self.root).as_posix()
                if full.is_symlink():
                    entries.append((rel, "L", hashlib.sha256(os.readlink(full).encode()).hexdigest()))
                elif full.is_file():
                    h = hashlib.sha256()
                    with full.open("rb") as f:
                        for block in iter(lambda: f.read(256 * 1024), b""):
                            h.update(block)
                    entries.append((rel, "F", h.hexdigest()))
        entries.sort()
        return Snapshot(canonical_hash(entries), len(entries), tuple(entries))

def definition_files_fingerprint(root: str | Path, relative_files: Sequence[str], *,
                                 allow_missing: bool = False) -> str:
    """Bind a selected visible test to its current test/config file bytes.

    File deletions, symlinks, path traversal and non-files fail closed. Caller
    supplies only approved visible test/config paths; NEVER protected tests.
    """
    root = Path(root).resolve(strict=True)
    if not relative_files or len(relative_files) != len(set(relative_files)):
        raise ValueError("Nonempty unique visible test definition paths required")
    entries = []
    for name in sorted(relative_files):
        relative = Path(name)
        if (not name or relative.is_absolute() or any(x in {"..", "."} for x in relative.parts)
            or relative.as_posix() != name):
            raise ValueError("Invalid or noncanonical visible definition path")
        path = root / relative
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise ValueError("Visible definition unsafe or symlinked")
        if not path.is_file():
            if (allow_missing and not path.exists() and
                (name in RICH_OPTIONAL_TEST_DEFINITIONS or relative.name == "conftest.py")):
                entries.append((name, 'ABSENT_AT_FREEZE'))
                continue
            raise ValueError("Visible definition missing or unsafe")
        entries.append((name, hashlib.sha256(path.read_bytes()).hexdigest()))
    return canonical_hash(entries)

CONFIG_FILES = ('setup.py', 'setup.cfg', 'pytest.ini', '.pytest.ini', 'pytest.toml',
                '.pytest.toml', 'pyproject.toml', 'tox.ini', 'conftest.py')

HERMETIC_INI = """[pytest]
addopts = -p no:anyio
norecursedirs = .* build dist venv
python_classes = Test* *Test
python_files = test_*.py *_test.py
filterwarnings =
    ignore::DeprecationWarning
    ignore::UserWarning
"""

HERMETIC_HEADER = '# Hermetic test discovery hook for SWE-gemma\n'

def snapshot_link_target(name, linkname, symbolic):
    if not linkname or PurePosixPath(linkname).is_absolute() or "\\" in linkname:
        raise CPUHold("UNSAFE_SNAPSHOT_LINK", f"Invalid target for {name}: {linkname[:180]}")
    base = name.parent.as_posix() if symbolic else "."
    target = PurePosixPath(posixpath.normpath(posixpath.join(base, linkname)))
    if ".." in target.parts or target == PurePosixPath("."):
        raise CPUHold("UNSAFE_SNAPSHOT_LINK", f"Target escapes or points to the archive root: {name}")
    return target

def install_snapshot_links(destination, links, regular):
    # Ordinary files are extracted first, so archive contents cannot be written through a link.
    for name, entry in links.items():
        path = destination / name
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() or path.is_symlink():
            raise CPUHold("UNSAFE_SNAPSHOT_LINK", f"Link collides with a staged file or directory: {name}")
        if entry["kind"] == "hardlink":
            target = entry["target"]
            visited = {name}
            while target in links and links[target]["kind"] == "hardlink" and target not in visited:
                visited.add(target)
                target = links[target]["target"]
            if target not in regular:
                raise CPUHold("UNSAFE_SNAPSHOT_LINK", f"Hardlink lacks an in-archive regular target: {name}")
            os.link(destination / target, path, follow_symlinks=False)
    for name, entry in links.items():
        if entry["kind"] == "symlink":
            path = destination / name
            if path.exists() or path.is_symlink():
                raise CPUHold("UNSAFE_SNAPSHOT_LINK", f"Symbolic link collides with a staged path: {name}")
            path.symlink_to(entry["linkname"])
    for name, entry in links.items():
        path = destination / name
        try:
            target = path.resolve(strict=True)
        except (OSError, RuntimeError) as exc:
            raise CPUHold("UNSAFE_SNAPSHOT_LINK", f"Broken or cyclic archive link: {name}") from exc
        if not target.is_relative_to(destination) or target in path.parents:
            raise CPUHold("UNSAFE_SNAPSHOT_LINK", f"Archive link target escapes or cycles to an ancestor: {name}")

def stage_public_snapshot(archive, destination, repo, deadline):
    destination = destination.resolve()
    destination.mkdir()
    total = 0
    regular, links = set(), {}
    with tarfile.open(archive, "r|gz") as tar:
        for member in tar:
            name = PurePosixPath(member.name)
            if name.is_absolute() or ".." in name.parts or "\\" in member.name:
                raise CPUHold("UNSAFE_SNAPSHOT_MEMBER", f"Unsafe archive path: {member.name[:200]}")
            remaining(deadline, POLICY["task_wall_seconds"])
            if member.issym() or member.islnk():
                if name in links or name in regular or name == PurePosixPath("."):
                    raise CPUHold("UNSAFE_SNAPSHOT_LINK", f"Duplicate or invalid archive link: {name}")
                links[name] = {
                    "kind": "symlink" if member.issym() else "hardlink",
                    "target": snapshot_link_target(name, member.linkname, member.issym()),
                    "linkname": member.linkname,
                }
                continue
            if not (member.isfile() or member.isdir()) or name in links or name in regular:
                raise CPUHold("UNSAFE_SNAPSHOT_MEMBER", f"Invalid or duplicate archive member: {name} ({member.type!r})")
            total += member.size
            if total > POLICY["snapshot_bytes_expanded_cap"]:
                raise CPUHold("SNAPSHOT_SIZE_LIMIT", "Expanded archive exceeded its CPU staging limit")
            tar.extract(member, destination, filter="data")
            if member.isfile():
                regular.add(name)
    install_snapshot_links(destination, links, regular)

    package, layouts = PACKAGE_LAYOUTS[repo]
    candidates = [
        (item.parent, layout) for item in destination.rglob(".git") if item.is_dir()
        for layout in layouts if (item.parent / layout / "__init__.py").is_file()
    ]
    if len(candidates) != 1:
        raise CPUHold("SNAPSHOT_LAYOUT", f"Expected one Git checkout containing {package}")
    root, package_dir = candidates[0]
    link_inventory = []
    for name, entry in sorted(links.items()):
        path = destination / name
        target = path if entry["kind"] == "symlink" else destination / entry["target"]
        if path.is_relative_to(root) and not target.resolve(strict=True).is_relative_to(root):
            raise CPUHold("UNSAFE_SNAPSHOT_LINK", f"Link in the checkout points outside it: {name}")
        link_inventory.append({"path": name.as_posix(), "kind": entry["kind"],
                               "target": entry["target"].as_posix()})
    return root, package, package_dir, link_inventory

def git_bytes(root, env, deadline, *argv):
    result = subprocess.run(
        ("git", "-C", str(root), *argv), env=env, capture_output=True,
        timeout=remaining(deadline, 20), check=False,
    )
    if result.returncode:
        raise CPUHold("NATIVE_GIT_PROBE", "Git could not read the mounted checkout identity")
    return result.stdout

def prepare_pytest_config(root):
    """Match the organizer subprocess harness's baseline pytest setup."""
    ini = root / "pytest.ini"
    text = ini.read_text(errors="replace") if ini.is_file() else ""
    if "# Hermetic test discovery" not in text and "[pytest]" not in text:
        ini.write_text(HERMETIC_INI, encoding="utf-8")
    conftest = root / "conftest.py"
    old = conftest.read_text(errors="replace") if conftest.is_file() else ""
    if not any(f"# {kind} test discovery hook for SWE-gemma" in old for kind in ("Hermetic", "Standard")):
        clean = old.replace(HERMETIC_HEADER, "").strip()
        conftest.write_text(HERMETIC_HEADER + ("\n" + clean if clean else "") + "\n", encoding="utf-8")

def visible_definition_paths(root):
    paths = set(RICH_OPTIONAL_TEST_DEFINITIONS)
    paths.update(name for name in CONFIG_FILES if (root / name).is_file())
    for path in (root / "tests").rglob("*"):
        relative = path.relative_to(root)
        if (any(part in EXCLUDED_DIRS for part in relative.parts)
                or path.name in EXCLUDED_NAMES or path.suffix in EXCLUDED_SUFFIXES):
            continue
        if path.is_file():
            paths.add(relative.as_posix())
    return tuple(sorted(paths))

def visible_definition_binding(root, files):
    regular, links = [], {}
    for name in files:
        path = root / name
        if not path.is_symlink():
            regular.append(name)
            continue
        target = path.resolve(strict=True)
        if not target.is_relative_to(root) or not target.is_file():
            raise CPUHold("UNSAFE_VISIBLE_DEFINITION_LINK", f"Invalid linked public fixture: {name}")
        links[name] = {"link_text": os.readlink(path), "target": target.relative_to(root).as_posix(),
                       "target_sha256": sha256_file(target)}
    digest = definition_files_fingerprint(root, regular, allow_missing=True)
    if links:
        digest = canonical_hash({"regular_sha256": digest, "internal_fixture_links": links})
    return digest, links

IMPORT_PROBE = """
import importlib
from pathlib import Path
import sys
module = importlib.import_module(sys.argv[1])
origin = Path(module.__file__).resolve()
print(origin)
if not origin.is_relative_to(Path(sys.argv[2]).resolve()):
    raise RuntimeError("Production package import escaped the public snapshot")
"""

CAPTURE_PLUGIN = """import json
import os
from pathlib import Path
import sys

def pytest_collection_finish(session):
    missing = set()
    if os.environ["GP03_PUBLIC_PACKAGE"] == "requests":
        for item in session.items:
            fixture_info = getattr(item, "_fixtureinfo", None)
            if fixture_info is None:
                continue
            for name in {"httpbin", "httpbin_secure"}.intersection(item.fixturenames):
                definitions = fixture_info.name2fixturedefs.get(name) or ()
                # Requests may wrap the plugin fixture by requesting its own name.
                if not any(name not in definition.argnames for definition in definitions):
                    missing.add(name)
    capture = {
        "root": str(session.config.rootpath.resolve()),
        "nodeids": [item.nodeid for item in session.items],
        "item_files": [str(item.path.resolve()) for item in session.items],
        "missing_optional_fixtures": sorted(missing),
    }
    Path(os.environ["GP03_CAPTURE_PATH"]).write_text(json.dumps(capture), encoding="utf-8")

def pytest_sessionfinish(session, exitstatus):
    target = Path(os.environ["GP03_CAPTURE_PATH"])
    if target.is_file():
        capture = json.loads(target.read_text(encoding="utf-8"))
        package = sys.modules.get(os.environ["GP03_PUBLIC_PACKAGE"])
        capture["production_origin"] = getattr(package, "__file__", None)
        target.write_text(json.dumps(capture), encoding="utf-8")
"""

def diagnostic_text(output):
    fragments = []
    for name in ("stdout.txt", "stderr.txt"):
        path = output / name
        with path.open("rb") as stream:
            head = stream.read(32 * 1024)
            if path.stat().st_size > len(head):
                stream.seek(max(len(head), path.stat().st_size - 32 * 1024))
                head += b"\n" + stream.read()
        fragments.append(head.decode("utf-8", errors="replace"))
    return "\n".join(fragments)

def missing_imports(text):
    return set(re.findall(r"ModuleNotFoundError: No module named ['\"]([A-Za-z0-9_.]+)['\"]", text))

def read_node_capture(path, selector, root, package_dir):
    if not path.is_file():
        raise CPUHold("NODE_CAPTURE_MISSING", "pytest produced no independent node ID capture")
    capture = json.loads(path.read_text(encoding="utf-8"))
    nodes = capture.get("nodeids", [])
    if not nodes:
        raise CPUHold("ZERO_COLLECTION", "The selected public suite collected zero tests")
    if len(nodes) > POLICY["max_collected_nodes"]:
        raise CPUHold("COLLECTION_LIMIT", f"Collected {len(nodes)} nodes, exceeding the frozen CPU cap")
    pytest_root = Path(capture["root"]).resolve(strict=True)
    if not pytest_root.is_relative_to(root):
        raise CPUHold("COLLECTION_IDENTITY", "pytest root is outside the staged checkout")
    files = capture.get("item_files", [])
    if len(files) != len(nodes):
        raise CPUHold("COLLECTION_IDENTITY", "pytest omitted a collected file identity")
    canonical = []
    for node, item_file in zip(nodes, files):
        if not isinstance(node, str):
            raise CPUHold("COLLECTION_IDENTITY", "Invalid pytest node ID")
        filename, delimiter, suffix = node.partition("::")
        relative = PurePosixPath(filename)
        if not delimiter or not suffix or relative.is_absolute() or ".." in relative.parts or "\\" in filename:
            raise CPUHold("COLLECTION_IDENTITY", "Invalid relative pytest node path")
        path_from_node = pytest_root / relative
        if (not path_from_node.is_relative_to(root) or str(path_from_node.resolve(strict=True)) != item_file):
            raise CPUHold("COLLECTION_IDENTITY", "Node path disagrees with the file collected by pytest")
        canonical.append(path_from_node.relative_to(root).as_posix() + "::" + suffix)
    if "::" in selector:
        permitted = lambda item: item == selector or item.startswith(selector + "[")
    else:
        permitted = lambda item: item.startswith(selector + "::")
    if not all(permitted(n) for n in canonical) or len(canonical) != len(set(canonical)):
        raise CPUHold("COLLECTION_IDENTITY", "Canonical node identities differ from the selector")
    origin = capture.get("production_origin")
    if origin and not Path(origin).resolve().is_relative_to(root / package_dir):
        raise CPUHold("PACKAGE_ORIGIN_CHANGED", "pytest imported production code outside the snapshot")
    return canonical, capture["missing_optional_fixtures"]

def run_visible_phase(*, selector, root, package, package_dir, temporary, output,
                      deadline, baseline_sha, collect_only):
    argv = [sys.executable, "-m", "pytest", selector, "-q", "--tb=short",
            "-p", "no:cacheprovider", "-p", "_gp03_capture"]
    capture = output / "nodeids.json"
    if collect_only:
        argv.append("--collect-only")
        cap = POLICY["collect_wall_seconds"]
    else:
        argv.append(f"--junitxml={output / 'junit.xml'}")
        cap = POLICY["baseline_wall_seconds"]
    result = bounded_command(
        argv, root, command_env(root, temporary, capture, package),
        output, remaining(deadline, cap),
    )
    result["source_sha256_after"] = WorkspaceFingerprinter(root).snapshot().sha256
    write_json(output / "command.json", result)
    if result["source_sha256_after"] != baseline_sha:
        raise CPUHold("SOURCE_CHANGED", "The selected pytest command changed the staged source or test definitions")
    if result["timed_out"]:
        reason = "COLLECTION_TIMEOUT" if collect_only else "BASELINE_TIMEOUT"
        raise CPUHold(reason, "The selected public pytest command exceeded its CPU limit")
    if collect_only and result["exit_code"] == 5:
        raise CPUHold("ZERO_COLLECTION", "The selected public suite collected zero tests")
    return result, capture

def junit_counts(junit: Path | bytes) -> tuple[int, int, int, int, int]:
    """Extract actual testcase elements; never trust exit code or suite labels alone."""
    data = junit if isinstance(junit, bytes) else junit.read_bytes()
    root = ET.fromstring(data)
    cases = [el for el in root.iter() if el.tag.rsplit("}", 1)[-1] == "testcase"]
    collected = len(cases)
    fail = sum(any(c.tag.rsplit("}", 1)[-1] == "failure" for c in t) for t in cases)
    err = sum(any(c.tag.rsplit("}", 1)[-1] == "error" for c in t) for t in cases)
    skipped = sum(any(c.tag.rsplit("}", 1)[-1] == "skipped" for c in t) for t in cases)
    passed = collected - fail - err - skipped
    if passed < 0 or collected != fail + err + skipped + passed:
        raise ValueError("Contradictory JUnit testcase counts")
    return collected, passed, fail, err, skipped

def artifact_paths(folder, excluded=()):
    files = {}
    for path in sorted(folder.rglob("*")):
        relative = path.relative_to(folder).as_posix()
        if path.is_symlink():
            raise CPUHold("UNSAFE_EVIDENCE_PATH", f"Symlink in CPU evidence at {relative}")
        if path.is_file() and relative not in excluded:
            files[relative] = path
    return files

def seal_zip(output, files):
    """Write a new evidence archive and index every included file."""
    output = Path(output)
    index = {}
    temporary = output.with_suffix('.partial.zip')
    if output.exists() or temporary.exists():
        raise FileExistsError(f'Refusing to overwrite evidence {output}')
    try:
        with zipfile.ZipFile(temporary, 'x', compression=zipfile.ZIP_DEFLATED) as z:
            for name, path in sorted(files.items()):
                path = Path(path)
                if path.is_symlink() or not path.is_file():
                    raise ValueError(f'Unsafe evidence file {name}')
                index[name] = {'bytes': path.stat().st_size, 'sha256': sha256_file(path)}
                z.write(path, name)
            z.writestr('SHA256_MANIFEST.json', json.dumps(index, indent=2, sort_keys=True) + '\n')
        verify_zip(temporary)
        temporary.rename(output)
    finally:
        temporary.unlink(missing_ok=True)
    print(f'Evidence ZIP {output.name} | SHA-256 {sha256_file(output)}', flush=True)
    return output

def verify_zip(archive):
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        index = json.loads(z.read('SHA256_MANIFEST.json'))
        if len(names) != len(set(names)) or set(names) != set(index) | {'SHA256_MANIFEST.json'}:
            raise RuntimeError('ZIP member set disagrees with the checksum manifest')
        for name, pin in index.items():
            path = Path(name)
            if path.is_absolute() or '..' in path.parts or z.getinfo(name).file_size != pin['bytes']:
                raise RuntimeError(f'Invalid archive member {name}')
            digest = hashlib.sha256()
            with z.open(name) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(block)
            if digest.hexdigest() != pin['sha256']:
                raise RuntimeError(f'Archive checksum mismatch for {name}')
    return index

def offer_zip_download(bundle, auto_download=True, embed_limit_mb=10):
    from pathlib import Path
    import base64
    import html
    import json
    import os
    from IPython.display import FileLink, HTML, Javascript, display

    bundle = Path(bundle).resolve()
    relative = os.path.relpath(bundle, Path.cwd())
    print('ZIP ready:', bundle)
    print('If the browser does not start a download, use the Download ZIP button or Kaggle Output panel.')
    display(FileLink(relative))
    if bundle.stat().st_size > embed_limit_mb * 1024 * 1024:
        print('This ZIP exceeds the inline-download size limit; use the file link or Output panel.')
        return {'automatic_download_requested': False, 'download_confirmed': False, 'reason': 'size_limit'}

    encoded = base64.b64encode(bundle.read_bytes()).decode('ascii')
    name = html.escape(bundle.name, quote=True)
    button = ('<a download="' + name + '" href="data:application/zip;base64,' + encoded + '" '
              'style="display:inline-block;padding:12px 20px;background:#174EA6;color:white;'
              'text-decoration:none;border-radius:6px;font-weight:600">Download ZIP</a>')
    display(HTML(button))
    if auto_download:
        script = '''(function () {
  try {
    const payload = __PAYLOAD__;
    const bytes = Uint8Array.from(atob(payload), function (c) { return c.charCodeAt(0); });
    const url = URL.createObjectURL(new Blob([bytes], {type: "application/zip"}));
    const link = document.createElement("a");
    link.href = url;
    link.download = __FILENAME__;
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
  } catch (error) {
    console.info("Automatic ZIP download was not available; use the Download ZIP button or Output panel.", error);
  }
})();'''.replace('__PAYLOAD__', json.dumps(encoded)).replace('__FILENAME__', json.dumps(bundle.name))
        display(Javascript(script))
        print('Automatic browser-download request offered. Notebook code cannot confirm that your PC saved it.')
    return {'automatic_download_requested': bool(auto_download), 'download_confirmed': False,
            'fallbacks': ['Download ZIP button', 'file link', 'Kaggle Output panel']}

# Reused from the pinned GP02C-04B source gp02c_ledger.py.
ID_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,120}$")

@dataclass(frozen=True)
class VisibleCheck:
    check_id: str
    command: tuple[str, ...]
    definition_sha256: str
    reserve_seconds: float = 0.0
    origin: str = "visible_repo"
    working_dir: str = "."
    test_selection: str = ""
    expected_collected: int | None = None
    pinned_environment_sha256: str | None = None
    definition_files: tuple[str, ...] = ()
    definition_files_sha256: str | None = None
    allow_missing_definition_files: bool = False

    def __post_init__(self):
        if not ID_RE.fullmatch(self.check_id):
            raise ValueError("Unsafe visible check identifier")
        if self.origin != "visible_repo":
            raise ValueError("Only trusted visible-repository checks are allowed")
        if not self.command or not all(isinstance(x, str) and x for x in self.command):
            raise ValueError("Nonempty command tokens required")
        if not re.fullmatch(r"[0-9a-f]{64}", self.definition_sha256):
            raise ValueError("Check definition must have SHA-256 identity")
        if self.reserve_seconds < 0:
            raise ValueError("Negative estimate")
        if (Path(self.working_dir).is_absolute() or
            any(x == ".." for x in Path(self.working_dir).parts)):
            raise ValueError("Working directory must be workspace-relative")
        if self.expected_collected is not None and self.expected_collected < 1:
            raise ValueError("Expected collection must be positive")
        if self.pinned_environment_sha256 is not None and not re.fullmatch(
            r"[0-9a-f]{64}", self.pinned_environment_sha256):
            raise ValueError("Bad pinned environment fingerprint")
        if bool(self.definition_files) != bool(self.definition_files_sha256):
            raise ValueError("Pinned visible definition files and digest must be supplied together")
        if self.definition_files_sha256 and not re.fullmatch(r"[0-9a-f]{64}", self.definition_files_sha256):
            raise ValueError("Bad pinned visible definition content fingerprint")
        for path in self.definition_files:
            rel = Path(path)
            if (not path or rel.is_absolute() or ".." in rel.parts or rel.as_posix() != path):
                raise ValueError("Unsafe visible definition filename")

    @property
    def command_sha256(self) -> str:
        return canonical_hash(self.command)

@dataclass(frozen=True)
class TestObservation:
    exit_code: int | None
    tests_collected: int | None
    tests_passed: int | None
    tests_failed: int | None
    tests_errored: int | None
    elapsed_seconds: float
    stdout: str = ""
    stderr: str = ""
    timed_out: bool = False
    setup_error: bool = False
    tests_skipped: int | None = 0

    def __post_init__(self):
        if self.elapsed_seconds < 0:
            raise ValueError("Negative duration")
        for name in ("tests_collected", "tests_passed", "tests_failed", "tests_errored", "tests_skipped"):
            v = getattr(self, name)
            if v is not None and v < 0:
                raise ValueError(f"Negative test count: {name}")

    @property
    def observed_outcome(self) -> str:
        if self.timed_out or self.setup_error or self.exit_code is None:
            return "ERROR"
        counts = (self.tests_collected, self.tests_passed,
                  self.tests_failed, self.tests_errored, self.tests_skipped)
        if any(c is None for c in counts):
            return "ERROR"
        total, passed, failed, errored, skipped = counts
        if total < 1 or passed + failed + errored + skipped != total:
            return "ERROR"
        if errored > 0:
            return "ERROR"
        if failed > 0 and self.exit_code != 0:
            return "FAIL"
        if failed > 0 and self.exit_code == 0:
            return "ERROR"  # contradictory successful process
        if self.exit_code != 0:
            return "ERROR"  # e.g. missing dependency / collection failure
        if passed < 1:
            return "ERROR"  # all skipped / no executed positive check
        return "PASS"

# Reused from the pinned GP02C-04B source gp02c_live_adapter.py.
@dataclass
class RealDeadline:
    """One absolute clock per attempt. 840/900s defaults; no reset per check."""
    repair_cutoff_seconds: float = 840.0
    overall_cutoff_seconds: float = 900.0
    started_monotonic: float | None = None
    now: Callable[[], float] = time.monotonic

    def __post_init__(self):
        if not 0 < self.repair_cutoff_seconds < self.overall_cutoff_seconds:
            raise ValueError("Need 0 < repair cutoff < overall cutoff")
        if self.started_monotonic is None:
            self.started_monotonic = self.now()

    def remaining(self, phase: str) -> float:
        if phase not in {"ordinary", "proactive", "final"}:
            raise ValueError("Unrecognized execution phase")
        cap = self.overall_cutoff_seconds if phase == "final" else self.repair_cutoff_seconds
        return max(0.0, self.started_monotonic + cap - self.now())

    def elapsed(self) -> float:
        return self.now() - self.started_monotonic

def _read_head(path: Path, max_bytes: int = 6000) -> str:
    with path.open("rb") as f:
        return f.read(max_bytes).decode("utf-8", errors="replace")

def copy_gp03_workspace(source, destination):
    """Copy the public working tree and verify all links in the private copy."""
    source = source.resolve(strict=True)
    before = WorkspaceFingerprinter(source).snapshot()

    def ignore_generated(directory, names):
        ignored = set()
        for name in names:
            if Path(directory, name).is_dir():
                if name in EXCLUDED_DIRS:
                    ignored.add(name)
            elif name in EXCLUDED_NAMES or Path(name).suffix in EXCLUDED_SUFFIXES:
                ignored.add(name)
        return ignored

    shutil.copytree(source, destination, symlinks=True, ignore=ignore_generated)
    copied = WorkspaceFingerprinter(destination).snapshot()
    if copied.sha256 != before.sha256:
        raise CPUHold("ISOLATED_COPY_MISMATCH", "Public source fingerprint changed during copying")
    links = []
    for name, kind, _ in copied.entries:
        if kind != "L":
            continue
        link = destination / name
        target_text = os.readlink(link)
        snapshot_link_target(PurePosixPath(name), target_text, symbolic=True)
        try:
            target = link.resolve(strict=True)
        except (OSError, RuntimeError) as exc:
            raise CPUHold("UNSAFE_ISOLATED_LINK", f"Broken or cyclic public link {name}") from exc
        if (not target.is_relative_to(destination) or target == destination
                or (target.is_dir() and link.parent.is_relative_to(target))
                or not (target.is_dir() or target.is_file())):
            raise CPUHold("UNSAFE_ISOLATED_LINK", f"Unsafe public link {name}")
        links.append({"path": name, "target": target.relative_to(destination).as_posix()})
    return before.sha256, links


def gp03_check_from_manifest(manifest):
    fields = dict(manifest["check"])
    fields["command"] = tuple(fields["command"])
    fields["definition_files"] = tuple(fields["definition_files"])
    return VisibleCheck(**fields)


class GP03PublicPytestAdapter:
    """Execute one pinned public check and return the controller's TestObservation."""

    def __init__(self, *, source_root, manifest, environment_sha256, deadline, results_root):
        self.source_root = Path(source_root).resolve(strict=True)
        self.results_root = Path(results_root).resolve()
        if (self.results_root.is_relative_to(self.source_root)
                or self.source_root.is_relative_to(self.results_root)):
            raise ValueError("Evidence and source must be in separate directories")
        self.results_root.mkdir(parents=True, exist_ok=True)
        self.manifest = manifest
        self.check = gp03_check_from_manifest(manifest)
        self.environment_sha256 = environment_sha256
        self.deadline = deadline
        self.phase = "ordinary"
        self.executions = []

    def _validate_definition(self, check, root):
        selector = check.test_selection
        if (check != self.check or check.working_dir != "."
                or check.pinned_environment_sha256 != self.environment_sha256
                or check.command != (sys.executable, "-m", "pytest", selector, "-q", "--tb=short")
                or not PUBLIC_TEST.fullmatch(selector.partition("::")[0])):
            raise CPUHold("CHECK_PIN_MISMATCH", "The trusted public command differs from its pin")
        files = visible_definition_paths(root)
        if files != check.definition_files:
            raise CPUHold("VISIBLE_DEFINITION_SET_CHANGED", "The public test or configuration file set changed")
        definition_sha, fixture_links = visible_definition_binding(root, files)
        if (definition_sha != check.definition_files_sha256
                or fixture_links != self.manifest.get("definition_link_targets", {})):
            raise CPUHold("VISIBLE_DEFINITION_CHANGED", "The public test, configuration or fixture bytes changed")

    def __call__(self, check):
        started = time.monotonic()
        absolute_deadline = started + self.deadline.remaining(self.phase)
        folder = self.results_root / f"check_{len(self.executions) + 1:04d}"
        folder.mkdir()
        receipt = {"check_id": check.check_id, "phase": self.phase, "reason": None}
        phase = folder / "pytest"
        counts = (None,) * 5
        exit_code = None
        try:
            remaining(absolute_deadline, POLICY["baseline_wall_seconds"])
            with tempfile.TemporaryDirectory(prefix="gp03_isolated_", dir=self.results_root.parent) as work:
                temporary = Path(work).resolve()
                isolated = temporary / "checkout"
                source_sha, links = copy_gp03_workspace(self.source_root, isolated)
                receipt.update(source_sha256_before=source_sha, isolated_links=links)
                self._validate_definition(check, isolated)
                package = PACKAGE_LAYOUTS[self.manifest["repo"]][0]
                package_dir = self.manifest["production_root"].rstrip("/")
                (temporary / "_gp03_capture.py").write_text(CAPTURE_PLUGIN, encoding="utf-8")
                result, capture = run_visible_phase(
                    selector=check.test_selection, root=isolated, package=package, package_dir=package_dir,
                    temporary=temporary, output=phase, deadline=absolute_deadline,
                    baseline_sha=source_sha, collect_only=False,
                )
                exit_code = result["exit_code"]
                nodes, missing = read_node_capture(capture, check.test_selection, isolated, package_dir)
                junit = phase / "junit.xml"
                counts = junit_counts(junit)
                receipt.update(actual_nodeids_sha256=canonical_hash(nodes), junit_sha256=sha256_file(junit),
                               isolated_source_sha256_after=result["source_sha256_after"])
                total, passed, failed, errors, skipped = counts
                if missing or nodes != self.manifest["expected_nodeids"] or total != check.expected_collected:
                    raise CPUHold("CHECK_NODE_MISMATCH", "Public check collection differs from its frozen node IDs")
                if errors or total == skipped or (exit_code, bool(failed)) not in {(0, False), (1, True)}:
                    raise CPUHold("PUBLIC_PYTEST_ERROR", "JUnit and the pytest exit status do not show a complete check")
                if failed and missing_imports(diagnostic_text(phase)):
                    raise CPUHold("PUBLIC_PYTEST_DEPENDENCY", "A completed test raised a missing dependency error")
                remaining(absolute_deadline, 1)
        except CPUHold as exc:
            receipt.update(reason=exc.reason, detail=str(exc))
        except (OSError, ValueError, ET.ParseError) as exc:
            receipt.update(reason="PUBLIC_CHECK_ERROR", detail=f"{type(exc).__name__}: {exc}")
        finally:
            if "source_sha256_before" in receipt:
                after = WorkspaceFingerprinter(self.source_root).snapshot().sha256
                receipt["source_sha256_after"] = after
                if after != receipt["source_sha256_before"]:
                    receipt.update(reason="ORIGINAL_SOURCE_CHANGED", detail="Source changed while pytest ran")
        total, passed, failed, errors, skipped = counts
        stdout = _read_head(phase / "stdout.txt") if (phase / "stdout.txt").is_file() else ""
        stderr = _read_head(phase / "stderr.txt") if (phase / "stderr.txt").is_file() else ""
        if not receipt["reason"] and time.monotonic() >= absolute_deadline:
            receipt.update(reason="TASK_DEADLINE", detail="The public check exceeded its phase deadline")
        if receipt["reason"]:
            stderr += f"\n{receipt['reason']} | {receipt['detail']}"
        observation = TestObservation(
            exit_code, total, passed, failed, errors, round(time.monotonic() - started, 3),
            stdout=stdout, stderr=stderr,
            timed_out=receipt["reason"] in {"TASK_DEADLINE", "BASELINE_TIMEOUT"},
            setup_error=receipt["reason"] is not None, tests_skipped=skipped,
        )
        receipt.update(outcome=observation.observed_outcome, observation=asdict(observation))
        write_json(folder / "Public_Check_Receipt.json", receipt)
        self.executions.append(receipt)
        return observation

# Reused from the pinned GP02C-04B source gp02c_ledger.py.
ARMS = {"A", "B", "C"}

PROVENANCES = {"agent", "controller_recheck", "final_gate", "common_initial"}

SCHEMA = "gp02c.ledger.v1.3"

def utc_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat()

@dataclass(frozen=True)
class VisibleManifest:
    checks: tuple[VisibleCheck, ...]
    strict: bool = False

    def __post_init__(self):
        ids = [c.check_id for c in self.checks]
        if not ids or len(ids) != len(set(ids)):
            raise ValueError("Manifest needs at least one unique selected visible check")
        if self.strict and any(c.expected_collected is None or
                               c.pinned_environment_sha256 is None or
                               not c.test_selection for c in self.checks):
            raise ValueError("Strict manifests must pin collection, environment, and selection")

    def get(self, check_id: str) -> VisibleCheck:
        for check in self.checks:
            if check.check_id == check_id:
                return check
        raise ValueError("Unselected or protected check is not allowed")

    @property
    def sha256(self) -> str:
        return canonical_hash([asdict(c) for c in self.checks])

@dataclass(frozen=True)
class Receipt:
    receipt_id: str
    run_id: str
    task_id: str
    arm: str
    seed: int
    check_id: str
    command: tuple[str, ...]
    command_definition_sha256: str
    command_sha256: str
    working_dir: str
    test_selection: str
    expected_collected: int | None
    workspace_revision_at_start: int
    workspace_revision_at_end: int
    workspace_sha256_at_start: str
    workspace_sha256_at_end: str
    environment_sha256: str
    timestamp_start: str
    timestamp_end: str
    exit_code: int | None
    tests_collected: int | None
    tests_passed: int | None
    tests_failed: int | None
    tests_errored: int | None
    tests_skipped: int | None
    qualification_error: str | None
    stdout_sha256: str
    stderr_sha256: str
    provenance: str
    observed_outcome: str
    elapsed_seconds: float
    timed_out: bool
    setup_error: bool
    test_completed_monotonic: float

@dataclass(frozen=True)
class ChangeEvent:
    action: str
    previous_revision: int
    new_revision: int
    changed: bool
    previous_sha256: str
    new_sha256: str
    edit_observed_monotonic: float

class EvidenceLedger:
    def __init__(self, root: str | Path, manifest: VisibleManifest,
                 *, run_id: str, task_id: str, arm: str, seed: int,
                 environment_sha256: str):
        if arm not in ARMS:
            raise ValueError("Unknown arm")
        for value in (run_id, task_id):
            if not ID_RE.fullmatch(value):
                raise ValueError("Unsafe run/task id")
        if not re.fullmatch(r"[0-9a-f]{64}", environment_sha256):
            raise ValueError("Expected environment SHA-256")
        self.fingerprinter = WorkspaceFingerprinter(root)
        self.manifest = manifest
        self.run_id = run_id
        self.task_id = task_id
        self.arm = arm
        self.seed = seed
        self.environment_sha256 = environment_sha256
        self.snapshot = self.fingerprinter.snapshot()
        self.revision = 0
        self.receipts: list[Receipt] = []
        self.changes: list[ChangeEvent] = []
        self.events: list[dict] = []
        self.unqualified_receipts: dict[str, str] = {}
        # Only a pass CURRENT AT THE INVALIDATING EDIT may start a regression pair.
        # Pending exposures are cleared on a later qualified check; old passes
        # cannot be resurrected after PASS -> FAIL -> edit -> FAIL.
        self.pending_regression_exposures: dict[str, dict] = {}

    def observe_workspace(self, action: str) -> ChangeEvent:
        new = self.fingerprinter.snapshot()
        old = self.snapshot
        before = self.revision
        changed = new.sha256 != old.sha256
        if changed:
            # Evaluate *prior to* advancing the source revision. The current
            # pass must be the latest qualified receipt for that check.
            for check in self.manifest.checks:
                prior = self.latest(check.check_id)
                if (prior is not None
                    and prior.observed_outcome == "PASS"
                    and prior.receipt_id not in self.unqualified_receipts
                    and prior.qualification_error is None
                    and prior.workspace_revision_at_start == self.revision
                    and prior.workspace_revision_at_end == self.revision
                    and prior.workspace_sha256_at_start == old.sha256
                    and prior.workspace_sha256_at_end == old.sha256
                    and prior.environment_sha256 == self.environment_sha256
                    and prior.command_definition_sha256 == check.definition_sha256
                    and (not check.definition_files_sha256 or
                         self._definition_matches(check))):
                    self.pending_regression_exposures.setdefault(check.check_id, {
                        "prior_receipt_id": prior.receipt_id,
                        "prior_revision": self.revision,
                        "edit_revision": self.revision + 1,
                        "edit_monotonic": time.monotonic(),
                        "prior_env": prior.environment_sha256,
                        "prior_command": prior.command_sha256,
                        "prior_definition": prior.command_definition_sha256,
                    })
            self.revision += 1
            self.snapshot = new
        ev = ChangeEvent(action, before, self.revision, changed, old.sha256,
                         new.sha256, time.monotonic())
        self.changes.append(ev)
        return ev

    def _definition_matches(self, check: VisibleCheck) -> bool:
        if not check.definition_files_sha256:
            return True  # Legacy CPU fixtures; GP02C-04 pilot requires pinned files.
        try:
            if check.check_id.startswith('dev_'):
                from gp02c_dev_registry import validate_check_definition
                return validate_check_definition(self.fingerprinter.root, check)
            return (definition_files_fingerprint(self.fingerprinter.root, check.definition_files,
                                               allow_missing=check.allow_missing_definition_files)
                    == check.definition_files_sha256)
        except (ValueError, OSError):
            return False

    def set_environment(self, environment_sha256: str) -> bool:
        if not re.fullmatch(r"[0-9a-f]{64}", environment_sha256):
            raise ValueError("Expected environment SHA-256")
        changed = self.environment_sha256 != environment_sha256
        self.environment_sha256 = environment_sha256
        if changed:
            self.events.append({"type": "environment_changed", "timestamp": utc_timestamp()})
        return changed

    def status(self, receipt: Receipt) -> str:
        check = self.manifest.get(receipt.check_id)
        self.observe_workspace("status_sync")  # detect out-of-band source changes
        if self.latest(check.check_id) is not receipt:
            return "STALE"
        if (receipt.workspace_revision_at_start != receipt.workspace_revision_at_end
            or receipt.workspace_sha256_at_start != receipt.workspace_sha256_at_end
            or receipt.workspace_revision_at_end != self.revision
            or receipt.workspace_sha256_at_end != self.snapshot.sha256
            or receipt.environment_sha256 != self.environment_sha256
            or receipt.command_definition_sha256 != check.definition_sha256
            or not self._definition_matches(check)
            or receipt.command_sha256 != check.command_sha256
            or receipt.working_dir != check.working_dir
            or receipt.test_selection != check.test_selection
            or (check.pinned_environment_sha256 is not None and
                check.pinned_environment_sha256 != self.environment_sha256)):

            return "STALE"
        if receipt.qualification_error or receipt.receipt_id in self.unqualified_receipts:
            return "ERROR"
        return {"PASS": "CURRENT_PASS", "FAIL": "CURRENT_FAIL"}.get(
            receipt.observed_outcome, "ERROR")

    def latest(self, check_id: str) -> Receipt | None:
        self.manifest.get(check_id)
        for receipt in reversed(self.receipts):
            if receipt.check_id == check_id:
                return receipt
        return None

    def current_status(self, check_id: str) -> str:
        r = self.latest(check_id)
        return self.status(r) if r else "NOT_EXECUTED"

    def selected_current_passes(self) -> tuple[str, ...]:
        return tuple(c.check_id for c in self.manifest.checks
                     if self.current_status(c.check_id) == "CURRENT_PASS")

    def record_check(self, check_id: str, provenance: str,
                     executor: Callable[[VisibleCheck], TestObservation], *,
                     receipt_qualifier: Callable[[Receipt], None] | None = None) -> Receipt:
        if provenance not in PROVENANCES:
            raise ValueError("Invalid provenance")
        check = self.manifest.get(check_id)
        self.observe_workspace("before_visible_check")
        start = self.snapshot
        rev_start = self.revision
        started = utc_timestamp()
        outcome = executor(check)
        if not isinstance(outcome, TestObservation):
            raise TypeError("Trusted visible executor must return TestObservation")
        ended = utc_timestamp()
        self.observe_workspace("after_visible_check")
        receipt = Receipt(
            receipt_id=f"visible-{len(self.receipts)+1:06d}",
            run_id=self.run_id, task_id=self.task_id, arm=self.arm, seed=self.seed,
            check_id=check.check_id, command=check.command,
            command_definition_sha256=check.definition_sha256,
            command_sha256=check.command_sha256,
            working_dir=check.working_dir, test_selection=check.test_selection,
            expected_collected=check.expected_collected,
            workspace_revision_at_start=rev_start,
            workspace_revision_at_end=self.revision,
            workspace_sha256_at_start=start.sha256,
            workspace_sha256_at_end=self.snapshot.sha256,
            environment_sha256=self.environment_sha256,
            timestamp_start=started, timestamp_end=ended,
            exit_code=outcome.exit_code, tests_collected=outcome.tests_collected,
            tests_passed=outcome.tests_passed, tests_failed=outcome.tests_failed,
            tests_errored=outcome.tests_errored,
            tests_skipped=outcome.tests_skipped,
            qualification_error=(
                "VISIBLE_DEFINITION_CHANGED" if not self._definition_matches(check) else
                "UNEXPECTED_COLLECTION" if check.expected_collected is not None
                and outcome.tests_collected != check.expected_collected else
                "ENVIRONMENT_MISMATCH" if check.pinned_environment_sha256 is not None
                and self.environment_sha256 != check.pinned_environment_sha256 else None),
            stdout_sha256=hashlib.sha256(outcome.stdout.encode()).hexdigest(),
            stderr_sha256=hashlib.sha256(outcome.stderr.encode()).hexdigest(),
            provenance=provenance, observed_outcome=outcome.observed_outcome,
            elapsed_seconds=outcome.elapsed_seconds, timed_out=outcome.timed_out,
            setup_error=outcome.setup_error,
            test_completed_monotonic=time.monotonic())
        # Raw observation is immutable. Qualification is completed BEFORE
        # deriving any observed-regression event.
        self.receipts.append(receipt)
        if receipt_qualifier is not None:
            receipt_qualifier(receipt)
        exposure = self.pending_regression_exposures.get(check_id)
        valid = (receipt.receipt_id not in self.unqualified_receipts
                 and receipt.qualification_error is None
                 and receipt.observed_outcome in {"PASS", "FAIL"}
                 and receipt.workspace_revision_at_start == receipt.workspace_revision_at_end
                 and receipt.workspace_sha256_at_start == receipt.workspace_sha256_at_end)
        if valid and exposure is not None:
            if (receipt.observed_outcome == "FAIL"
                and exposure["edit_revision"] <= receipt.workspace_revision_at_end
                and exposure["prior_env"] == receipt.environment_sha256
                and exposure["prior_command"] == receipt.command_sha256
                and exposure["prior_definition"] == receipt.command_definition_sha256):
                self.events.append({
                    "type": "OBSERVED_PASS_TO_FAIL_AFTER_EDIT",
                    "check_id": check_id,
                    "prior_receipt_id": exposure["prior_receipt_id"],
                    "failure_receipt_id": receipt.receipt_id,
                    "prior_revision": exposure["prior_revision"],
                    "failure_revision": receipt.workspace_revision_at_end,
                    "invalidating_edit_observed_monotonic": exposure["edit_monotonic"],
                    "failure_observed_monotonic": receipt.test_completed_monotonic,
                    "edit_to_detection_seconds": max(
                        0.0, receipt.test_completed_monotonic - exposure["edit_monotonic"]),
                })
            # A qualified result resolves the exposure. A later failure cannot
            # piggyback on an old pass after this check has already failed.
            self.pending_regression_exposures.pop(check_id, None)
        return receipt

    def disqualify_receipt(self, receipt: Receipt, reason: str) -> None:
        """Fail closed on controller-budget violations without mutating raw observations."""
        self.unqualified_receipts[receipt.receipt_id] = reason
        self.events.append({"type": "RECEIPT_UNQUALIFIED", "receipt_id": receipt.receipt_id,
                            "reason": reason})

    def export(self) -> dict:
        # Refresh revision *before* writing any status rows or reporting a hash.
        self.observe_workspace("export_preflight")
        return {
            "schema": SCHEMA, "run_id": self.run_id, "task_id": self.task_id,
            "arm": self.arm, "seed": self.seed, "manifest_sha256": self.manifest.sha256,
            "workspace_revision": self.revision, "workspace_sha256": self.snapshot.sha256,
            "environment_sha256": self.environment_sha256,
            "receipts": [{**asdict(r), "status": self.status(r),
                          "controller_disqualification": self.unqualified_receipts.get(r.receipt_id)}
                         for r in self.receipts],
            "changes": [asdict(e) for e in self.changes],
            "events": list(self.events),
        }

@dataclass
class SharedBudget:
    max_wall_seconds: float = 900.0
    max_tool_calls: int = 60
    max_model_calls: int = 60
    used_wall_seconds: float = 0.0
    used_tool_calls: int = 0
    used_model_calls: int = 0
    used_test_runs: int = 0
    final_reserve_seconds: float = 60.0

    @property
    def remaining_wall(self) -> float:
        return max(0.0, self.max_wall_seconds - self.used_wall_seconds)

    def can_run_check(self, check: VisibleCheck, *, protect_final_reserve: bool = False) -> bool:
        reserve = self.final_reserve_seconds if protect_final_reserve else 0.0
        return (self.used_tool_calls < self.max_tool_calls
                and self.remaining_wall > 0
                and self.remaining_wall >= check.reserve_seconds + reserve)

    @property
    def remaining_repair_wall(self) -> float:
        return max(0.0, self.max_wall_seconds - self.final_reserve_seconds - self.used_wall_seconds)

    @property
    def over_limit(self) -> bool:
        return (self.used_wall_seconds > self.max_wall_seconds
                or self.used_tool_calls > self.max_tool_calls
                or self.used_model_calls > self.max_model_calls)

    def charge_model(self, elapsed_seconds: float = 0.0) -> None:
        if self.used_model_calls >= self.max_model_calls:
            raise RuntimeError("Model budget exhausted")
        self.used_model_calls += 1
        self.used_wall_seconds += elapsed_seconds

    def charge_tool(self, elapsed_seconds: float = 0.0) -> None:
        if self.used_tool_calls >= self.max_tool_calls:
            raise RuntimeError("Tool budget exhausted")
        self.used_tool_calls += 1
        self.used_wall_seconds += elapsed_seconds

    def charge_visible_test(self, elapsed_seconds: float) -> None:
        # Executing a selected check also consumes one shared tool invocation.
        self.charge_tool(elapsed_seconds)
        self.used_test_runs += 1

    def summary(self) -> dict:
        return {"used_wall_seconds": self.used_wall_seconds,
                "remaining_wall_seconds": self.remaining_wall,
                "used_tool_calls": self.used_tool_calls,
                "used_model_calls": self.used_model_calls,
                "used_test_runs": self.used_test_runs}

@dataclass(frozen=True)
class GateDecision:
    accepted: bool
    status: str
    checks: dict[str, str]
    attempts: int
    accepted_patch_sha256: str | None = None
    accepted_workspace_sha256: str | None = None
    accepted_revision: int | None = None

class VerificationController:
    """Trusted wrapper prototype. Same gate implementation for B and C.

    Executor is a trusted *visible* check adapter; NEVER pass hidden evaluator
    results. This prototype uses deterministic duration accounting. Live GP02C-03
    must enforce wall time and tool/model counters on the actual worker.
    """
    def __init__(self, ledger: EvidenceLedger, budget: SharedBudget,
                 executor: Callable[[VisibleCheck], TestObservation],
                 production_patch_sha256: Callable[[], str],
                 *, max_rechecks_per_edit: int = 4,
                 max_rechecks_per_run: int = 12):
        self.ledger = ledger
        self.budget = budget
        self.executor = executor
        self.production_patch_sha256 = production_patch_sha256
        if max_rechecks_per_edit < 0 or max_rechecks_per_run < 0:
            raise ValueError("Negative auto-recheck limit")
        self.max_rechecks_per_edit = max_rechecks_per_edit
        self.max_rechecks_per_run = max_rechecks_per_run
        self.auto_rechecks_used = 0

    def _patch_digest(self) -> str:
        digest = self.production_patch_sha256()
        if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise ValueError("Trusted production-patch capture must return a SHA-256 digest")
        return digest

    def _qualify_receipt(self, receipt: Receipt, *, check_id: str,
                         provenance: str, allowed_seconds: float) -> None:
        """Qualify budget/deadline before deriving observed-regression metrics."""
        proactive = provenance == "controller_recheck"
        if (receipt.elapsed_seconds > allowed_seconds + 1e-9 or
            self.budget.over_limit or
            (proactive and self.budget.remaining_repair_wall <= 0 and
             self.budget.used_wall_seconds > self.budget.max_wall_seconds - self.budget.final_reserve_seconds + 1e-9)):
            self.ledger.disqualify_receipt(receipt, "ACTUAL_RUNTIME_EXCEEDED_ALLOWED_DEADLINE")
            self.ledger.events.append({"type": "UNVERIFIED_BUDGET",
                                       "check_id": check_id, "provenance": provenance,
                                       "reason": "actual_runtime_overrun_requires_live_cancellation"})

    def _run_check(self, check_id: str, provenance: str) -> Receipt | None:
        check = self.ledger.manifest.get(check_id)
        proactive = provenance == "controller_recheck"
        if not self.budget.can_run_check(check, protect_final_reserve=proactive):
            self.ledger.events.append({"type": "UNVERIFIED_BUDGET", "check_id": check_id,
                                       "provenance": provenance})
            return None
        # CPU contract only: the caller-supplied executor is synchronous and NOT
        # cancellable. It must be replaced in GP02C-03 by a hard-deadline trusted
        # subprocess adapter, using a monotonic 840/900-second cutoff.
        allowed_seconds = (self.budget.remaining_repair_wall if proactive
                           else self.budget.remaining_wall)
        def recorded_executor(c: VisibleCheck) -> TestObservation:
            try:
                result = self.executor(c)
            except Exception as e:
                result = TestObservation(None, None, None, None, None,
                                         elapsed_seconds=0.0, setup_error=True)
                self.ledger.events.append({"type": "executor_error", "check_id": check_id,
                                           "error_type": type(e).__name__})
            self.budget.charge_visible_test(result.elapsed_seconds)
            return result
        return self.ledger.record_check(
            check_id, provenance, recorded_executor,
            receipt_qualifier=lambda receipt: self._qualify_receipt(
                receipt, check_id=check_id, provenance=provenance,
                allowed_seconds=allowed_seconds))

    def observe_agent_action(self, kind: str, action: Callable[[], object],
                             *, elapsed_seconds: float = 0.0) -> dict:
        """Wrap any tool action: read/edit/write/shell; no mandatory read gate.

        Charge the agent action itself; C post-edit checks are additional charged
        calls. Exceptions preserve before/after snapshots and are re-raised.
        """
        if (self.budget.used_tool_calls >= self.budget.max_tool_calls
            or self.budget.remaining_wall <= (
                self.budget.final_reserve_seconds if self.ledger.arm in {"B", "C"} else 0)):
            raise RuntimeError("Shared agent-tool budget exhausted or reserved for final validation")
        self.ledger.observe_workspace(f"before_{kind}")
        previously_passing = self.ledger.selected_current_passes()
        prior_snapshot = self.ledger.snapshot
        prior_receipts = {
            check_id: self.ledger.latest(check_id).receipt_id for check_id in previously_passing
        }
        exc: BaseException | None = None
        started_action = time.monotonic()
        try:
            result = action()
        except BaseException as error:
            exc = error
            result = None
        finally:
            # Actual wall time is charged for a live tool (the earlier integration
            # incorrectly passed 0.0). Explicit synthetic estimates are retained
            # for historical deterministic tests but never used by the ADK bridge.
            actual_action_seconds = time.monotonic() - started_action
            billed_action_seconds = (elapsed_seconds if elapsed_seconds > 0
                                     else actual_action_seconds)
            self.budget.charge_tool(billed_action_seconds)
            change = self.ledger.observe_workspace(f"after_{kind}")
        if change.changed and previously_passing:
            # Shared passive exposure instrumentation, identical B/C. STALE is
            # evidence invalidation, NOT proof of a test regression.
            old = {entry[0]: entry[1:] for entry in prior_snapshot.entries}
            new = {entry[0]: entry[1:] for entry in self.ledger.snapshot.entries}
            self.ledger.events.append({
                'type':'QUALIFIED_PASS_INVALIDATED_BY_RELEVANT_EDIT',
                'workspace_sha256_before': change.previous_sha256,
                'prior_receipts': prior_receipts,
                'changed_paths': sorted(path for path in old.keys() | new.keys()
                                        if old.get(path) != new.get(path)),
                'tool':kind, 'check_ids':list(previously_passing),
                'revision_before':change.previous_revision,
                'revision_after':change.new_revision,
                'workspace_sha256':change.new_sha256,
                'elapsed_agent_tool_seconds':round(billed_action_seconds,6)})
        reruns: list[dict[str, str]] = []
        if change.changed and self.ledger.arm == "C":
            for position, check_id in enumerate(previously_passing):
                if (position >= self.max_rechecks_per_edit or
                    self.auto_rechecks_used >= self.max_rechecks_per_run):
                    status = "UNVERIFIED_RECHECK_LIMIT"
                    self.ledger.events.append({"type": status, "check_id": check_id})
                else:
                    self.auto_rechecks_used += 1
                    receipt = self._run_check(check_id, "controller_recheck")
                    status = ("UNVERIFIED_BUDGET" if receipt is None or
                              receipt.receipt_id in self.ledger.unqualified_receipts or
                              self.budget.over_limit else self.ledger.status(receipt))
                reruns.append({"check_id": check_id, "status": status})
        # A later recheck can mutate the worktree and stale earlier rechecks.
        # Derive the entire feedback message from one final observed state.
        self.ledger.observe_workspace("post_recheck_feedback_sync")
        for row in reruns:
            if row["status"] in {"CURRENT_PASS", "CURRENT_FAIL", "STALE", "ERROR"}:
                row["status"] = self.ledger.current_status(row["check_id"])
        feedback = {"changed": change.changed, "revision": self.ledger.revision,
                    "workspace_sha256": self.ledger.snapshot.sha256,
                    "stale_selected_checks": list(previously_passing) if change.changed else [],
                    "rechecks": reruns}
        if exc is not None:
            raise exc
        return {"result": result, "feedback": feedback}

    def agent_visible_feedback(self, result: dict) -> dict:
        """Bounded and exclusively derived from allowlisted visible-check IDs.

        Never includes test stdout, stderr, hidden tests, reference patch,
        tool outputs or the model context; the integration must preserve this.
        """
        feedback = result["feedback"]
        return {"schema": "gp02c.feedback.v1", "revision": feedback["revision"],
                "changed": feedback["changed"],
                "workspace_sha256": feedback["workspace_sha256"],
                "stale": feedback["stale_selected_checks"][:32],
                "rechecks": feedback["rechecks"][:32]}

    def final_gate(self) -> GateDecision:
        if self.ledger.arm == "A":
            raise ValueError("Ordinary baseline A has no mandatory final gate")
        # Same B/C gate. Each decision revalidates all selected statuses *after*
        # the last source sync and is bound to the workspace SHA, revision,
        # production patch SHA and frozen manifest SHA.
        self.ledger.observe_workspace("final_gate_entry")
        initial_patch = self._patch_digest()
        attempts = 0
        max_attempts = len(self.ledger.manifest.checks) * 3

        def statuses_now() -> dict[str, str]:
            self.ledger.observe_workspace("final_gate_status_sync")
            return {c.check_id: self.ledger.current_status(c.check_id)
                    for c in self.ledger.manifest.checks}

        while True:
            statuses = statuses_now()
            # Do not declare exhaustion before reviewing the final allowed result.
            if all(s == "CURRENT_PASS" for s in statuses.values()):
                self.ledger.observe_workspace("final_gate_patch_sync")
                # The final sync may itself reveal a mutation. Recompute *after* it.
                statuses = statuses_now()
                workspace = self.ledger.snapshot.sha256
                revision = self.ledger.revision
                if self._patch_digest() != initial_patch:
                    return GateDecision(False, "PATCH_CHANGED_DURING_GATE", statuses, attempts)
                # One additional consistency check after the patch capture.
                self.ledger.observe_workspace("final_gate_approval_sync")
                statuses = statuses_now()
                if (all(s == "CURRENT_PASS" for s in statuses.values()) and
                    self.ledger.snapshot.sha256 == workspace and
                    self.ledger.revision == revision and
                    self._patch_digest() == initial_patch and
                    not self.budget.over_limit and self.budget.remaining_wall > 0):
                    return GateDecision(True, "VERIFIED_VISIBLE", statuses, attempts,
                                        accepted_patch_sha256=initial_patch,
                                        accepted_workspace_sha256=workspace,
                                        accepted_revision=revision)
            if self.budget.over_limit or self.budget.remaining_wall <= 0:
                return GateDecision(False, "UNVERIFIED_BUDGET", statuses, attempts)
            if any(s in {"CURRENT_FAIL", "ERROR"} for s in statuses.values()):
                return GateDecision(False, "VISIBLE_CHECK_FAILED", statuses, attempts)
            pending = [cid for cid, s in statuses.items()
                       if s in {"STALE", "NOT_EXECUTED"}]
            if not pending:
                return GateDecision(False, "UNVERIFIED", statuses, attempts)
            if attempts >= max_attempts:
                return GateDecision(False, "UNVERIFIED_RECHECK_LIMIT", statuses, attempts)
            receipt = self._run_check(pending[0], "final_gate")
            if receipt is None or receipt.receipt_id in self.ledger.unqualified_receipts:
                return GateDecision(False, "UNVERIFIED_BUDGET", statuses_now(), attempts)
            attempts += 1

# Reused from the pinned GP02C-04B source gp02c_live_adapter.py.
class LiveVerificationBridge(VerificationController):
    """B/C controller with actual time caps and a single-charge test executor.

    Only trusted subprocesses are cancellable here; ADK model requests and other
    agent tools must be routed via the equivalent hard-deadline worker in GP02C-04.
    """
    def __init__(self, ledger: EvidenceLedger, budget: SharedBudget,
                 executor: "GP03PublicPytestAdapter",
                 production_patch_sha256: Callable[[], str], **kwargs):
        super().__init__(ledger, budget, executor, production_patch_sha256, **kwargs)
        self.deadline = executor.deadline
        self.repair_deadline_breached = False

    def _qualify_receipt(self, receipt, *, check_id: str,
                         provenance: str, allowed_seconds: float) -> None:
        super()._qualify_receipt(receipt, check_id=check_id,
                                 provenance=provenance, allowed_seconds=allowed_seconds)
        phase = "proactive" if provenance == "controller_recheck" else (
            "final" if provenance == "final_gate" else "ordinary")
        if receipt.timed_out or self.deadline.remaining(phase) <= 0:
            if receipt.receipt_id not in self.ledger.unqualified_receipts:
                self.ledger.disqualify_receipt(receipt, "ABSOLUTE_DEADLINE")
                self.ledger.events.append({"type": "UNVERIFIED_BUDGET",
                                           "check_id": check_id, "provenance": provenance,
                                           "reason": "absolute_deadline"})

    def _run_check(self, check_id: str, provenance: str):
        phase = "proactive" if provenance == "controller_recheck" else (
            "final" if provenance == "final_gate" else "ordinary")
        if self.deadline.remaining(phase) <= 0:
            self.ledger.events.append({"type": "UNVERIFIED_BUDGET", "check_id": check_id,
                                       "provenance": provenance, "reason": "absolute_deadline"})
            return None
        old = self.executor.phase
        self.executor.phase = phase
        try:
            receipt = super()._run_check(check_id, provenance)
        finally:
            self.executor.phase = old
        return receipt

    def observe_agent_action(self, kind: str, action: Callable[[], object], **kwargs) -> dict:
        if self.deadline.remaining("ordinary") <= 0:
            raise RuntimeError("Absolute repair deadline exhausted")
        start = time.monotonic()
        budget_before = self.budget.used_wall_seconds
        try:
            return super().observe_agent_action(kind, action, elapsed_seconds=0.0)
        finally:
            # super has already charged all automatic checks; charge only action
            # and wrapper overhead (not another tool call, not double testing).
            wall = time.monotonic() - start
            already_charged = self.budget.used_wall_seconds - budget_before
            self.budget.used_wall_seconds += max(0.0, wall - already_charged)
            if self.deadline.remaining("ordinary") <= 0:
                self.repair_deadline_breached = True
                self.ledger.events.append({"type": "UNVERIFIED_BUDGET",
                                           "reason": "repair_deadline_reached_during_action"})

    def final_gate(self) -> GateDecision:
        if self.repair_deadline_breached:
            return GateDecision(False, "UNVERIFIED_BUDGET", {}, 0)
        if self.deadline.remaining("final") <= 0:
            return GateDecision(False, "UNVERIFIED_BUDGET", {}, 0)
        decision = super().final_gate()
        if (not decision.accepted and any(e.get("type") == "UNVERIFIED_BUDGET"
                                         and e.get("reason") == "absolute_deadline"
                                         for e in self.ledger.events)):
            return GateDecision(False, "UNVERIFIED_BUDGET", decision.checks, decision.attempts)
        if decision.accepted and self.deadline.remaining("final") <= 0:
            return GateDecision(False, "UNVERIFIED_BUDGET", decision.checks, decision.attempts)
        return decision

    def verify_delivery_identity(self, approved: GateDecision) -> bool:
        """Recheck both full workspace and trusted production-patch identities."""
        if not approved.accepted:
            return False
        self.ledger.observe_workspace("delivery_identity_sync")
        return (self.ledger.snapshot.sha256 == approved.accepted_workspace_sha256
                and self.ledger.revision == approved.accepted_revision
                and self._patch_digest() == approved.accepted_patch_sha256
                and self.deadline.remaining("final") > 0)

# Reused from the pinned GP02C-04B source gp02c04b_checkpoint.py.
class CaptureHold(RuntimeError):
    pass

PRODUCTION_ROOTS = ('rich/',)

SCRATCH_COMPONENTS = frozenset({'test', 'tests', 'example', 'examples', 'scratch',
    'scripts', '__pycache__', '.pytest_cache', '.venv', 'venv'})

SCRATCH_PREFIXES = ('repro', 'reproduce', 'scratch', 'debug', 'temp', 'tmp', 'probe', 'test_')

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def run_git(repo: Path, args: list[str], *, allowed=(0,), timeout=20):
    p=subprocess.run(['git', '-C', str(repo), *args], capture_output=True,timeout=timeout)
    if p.returncode not in allowed:
        raise CaptureHold('Git command rejected: '+str(args[:3])+': '+p.stderr.decode(errors='replace')[:250])
    return p

def is_production(rel: str, roots=PRODUCTION_ROOTS) -> bool:
    p=Path(rel)
    if (not rel or '\\' in rel or p.is_absolute() or '..' in p.parts or
        not any(rel.startswith(root) for root in roots)):
        return False
    if p.suffix not in ('.py', '.pyi'):
        return False
    if any(part.lower() in SCRATCH_COMPONENTS for part in p.parts):
        return False
    name=p.name.lower()
    if name.startswith(SCRATCH_PREFIXES) or name.endswith('_test.py'):
        return False
    return True

def candidate_bytes(workspace: Path, *, roots=PRODUCTION_ROOTS, base_ref="HEAD") -> tuple[bytes,dict]:
    workspace=Path(workspace).resolve(strict=True)
    if not (workspace/'.git').is_dir():
        raise CaptureHold('Live source lacks expected Git repository')
    tracked=run_git(workspace,['diff','--no-renames','--name-only','-z',base_ref,'--']).stdout
    unknown=run_git(workspace,['ls-files','--others','--exclude-standard','-z']).stdout
    edited=[v.decode('utf-8','surrogateescape') for v in tracked.split(b'\0') if v]
    untracked=[v.decode('utf-8','surrogateescape') for v in unknown.split(b'\0') if v]
    tracked_eligible=sorted(p for p in edited if is_production(p, roots))
    new_eligible=sorted(p for p in untracked if is_production(p, roots))
    for name in tracked_eligible+new_eligible:
        f=workspace/name
        if f.is_symlink() or (f.exists() and not f.is_file()):
            raise CaptureHold('Unsupported production-source file kind: '+name)
    patch=b''
    if tracked_eligible:
        patch+=run_git(workspace,['diff','--no-renames','--binary',base_ref,'--',*tracked_eligible]).stdout
    for rel in new_eligible:
        result=run_git(workspace,['diff','--no-index','--binary','--','/dev/null',rel],allowed=(1,))
        if b'new file mode' not in result.stdout:
            raise CaptureHold('Invalid untracked source diff: '+rel)
        patch+=result.stdout
    manifest={'schema':'gp02c04b.production-candidate.v1',
              'policy':'FROZEN_PACKAGE_SOURCE_ONLY',
              'roots':list(roots),
              'tracked':tracked_eligible,'untracked':new_eligible,
              'excluded':sorted(set(edited+untracked)-set(tracked_eligible+new_eligible)),
              'sha256':sha256(patch),'bytes':len(patch)}
    return patch,manifest

# Reused from the pinned GP02C-04B source gp02c04b_assurance.py.
class LiveSourceHold(RuntimeError):
    pass

def selected_visible_command(command:str, check_id:str='rich_style_visible', *,
                             selector='tests/test_style.py', allow_src_pythonpath=False)->str|None:
    """Recognise *whole* predeclared visible test selection without shell execution.

    This reports whether the agent actually requested the frozen test group. The
    GP02C trusted subprocess is still independently executed with pinned argv.
    Nontrivial shell pipelines, test node selectors, exclusions and arbitrary
    flags do NOT qualify as the full selected check.
    """
    if not isinstance(command,str) or '\n' in command or '\r' in command:
        return None
    try: tokens=shlex.split(command.strip(),posix=True)
    except ValueError: return None
    if tokens[:3]==['cd','/workspace','&&']:
        tokens=tokens[3:]
    if allow_src_pythonpath and tokens[:1] == ['PYTHONPATH=src']:
        tokens = tokens[1:]
    if not tokens: return None
    if tokens[0] in {'pytest','pytest3'}:
        tokens=tokens[1:]
    elif (len(tokens)>=3 and tokens[0] in {'python','python3','/usr/bin/python3'}
          and tokens[1:3]==['-m','pytest']):
        tokens=tokens[3:]
    else:return None
    # Formatting flags only; never trust -k/-m/-x/--maxfail/::node or shell operators.
    formatting = {'-q', '-v', '--disable-warnings', '--no-header', '--no-summary', '--tb=short'}
    selection = [token for token in tokens if token not in formatting]
    return check_id if selection == [selector] else None

def _proc_pid_state(pid: int) -> tuple[str, int | None]:
    """Actual process state and start ticks; absence is not an error."""
    try:
        rest=(Path('/proc') / str(pid) / 'stat').read_text().rsplit(')',1)[1].strip().split()
        return rest[0], int(rest[19])
    except FileNotFoundError:
        return 'ABSENT', None
    except (OSError, ValueError, IndexError):
        return 'UNKNOWN', None

def _start_ticks(pid:int):
    return _proc_pid_state(pid)[1]

def register_trusted_child(proc, env:dict, argv:tuple[str,...]):
    """Fsync allowed pytest child group identity for external parent supervisor."""
    reg=env.get('GP02C_TRUSTED_PYTEST_REGISTRY')
    if not reg:return
    if ('-m','pytest') != tuple(argv[1:3]):
        raise LiveSourceHold('Refusing to register untrusted child argv')
    row={'event':'TRUSTED_PYTEST_START','pid':proc.pid,'pgid':os.getpgid(proc.pid),
         'start_ticks':_start_ticks(proc.pid),
         'argv_sha256':canonical_hash(tuple(argv))}
    if (row['pid']!=row['pgid'] or os.getsid(proc.pid)!=proc.pid
            or row['start_ticks'] is None):
        raise LiveSourceHold('Missing auditable pytest process-group identity')
    path=Path(reg);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf-8') as f:
        f.write(json.dumps(row,sort_keys=True)+'\n');f.flush();os.fsync(f.fileno())

def _group_members(pgid: int) -> list[int]:
    # Use the kernel's group and session IDs. The /proc stat IDs can come from a
    # different namespace. Probe the known leader even if /proc omits its entry.
    candidates = {pgid}
    candidates.update(int(p.name) for p in Path('/proc').iterdir() if p.name.isdigit())
    members = []
    for pid in sorted(candidates):
        try:
            if os.getpgid(pid) == pgid and os.getsid(pid) == pgid:
                members.append(pid)
        except ProcessLookupError:
            continue
    return members

def _group_exists(pgid: int) -> bool:
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return False
    return True

def _process_active(pid: int) -> bool:
    # A pidfd distinguishes an exited, unreaped child from a running one, even
    # when the sandbox's process table still shows a sleeping process.
    if hasattr(os, 'pidfd_open'):
        try:
            fd = os.pidfd_open(pid)
        except ProcessLookupError:
            return False
        except OSError:
            pass
        else:
            try:
                poller = select.poll()
                poller.register(fd, select.POLLIN)
                return not poller.poll(0)
            finally:
                os.close(fd)
    return _proc_pid_state(pid)[0] not in {'Z', 'X', 'ABSENT'}

def _active_registered_group(pgid: int, start_ticks: int) -> list[int]:
    if not _group_exists(pgid):
        return []
    state, ticks = _proc_pid_state(pgid)
    if state != 'ABSENT' and ticks != start_ticks:
        raise LiveSourceHold('REGISTERED_LEADER_IDENTITY_UNVERIFIED')
    members = _group_members(pgid)
    if pgid in members and ticks != start_ticks:
        raise LiveSourceHold('REGISTERED_LEADER_IDENTITY_UNVERIFIED')
    if not members and _group_exists(pgid):
        raise LiveSourceHold('REGISTERED_GROUP_MEMBERSHIP_UNVERIFIED')
    return [pid for pid in members if _process_active(pid)]

def reap_trusted_groups(path:Path, *, grace:float=0.35)->dict:
    """Reap registered pytest sessions; hold on missing/malformed evidence.

    Reports only evidence-supported *registered-group* cleanup, never an
    unbounded claim about deliberately detached descendants or the vLLM server.
    """
    path=Path(path)
    report={'registry':str(path),'registry_present':path.is_file(),
            'registered':0,'groups_reaped':0,'errors':[], 'survivors':[],
            'verification_scope':'REGISTERED_TRUSTED_PROCESS_GROUPS',
            'verified':False}
    if not path.is_file():
        report['errors'].append('REGISTRY_MISSING')
        return report
    rows=[]
    try: lines=path.read_text(encoding='utf-8').splitlines()
    except (OSError, UnicodeError):
        report['errors'].append('REGISTRY_UNREADABLE')
        return report
    for idx,line in enumerate(lines,1):
        if not line.strip():
            report['errors'].append('EMPTY_REGISTRY_LINE_'+str(idx));continue
        try:
            r=json.loads(line)
            if not (isinstance(r,dict) and r.get('event')=='TRUSTED_PYTEST_START' and
                type(r.get('pid')) is int and r['pid']>1 and r.get('pgid')==r['pid'] and
                type(r.get('start_ticks')) is int and r['start_ticks']>=0):
                raise ValueError('bad record')
            rows.append(r)
        except (ValueError,TypeError,KeyError):
            report['errors'].append('MALFORMED_REGISTRATION_'+str(idx))
    report['registered']=len(rows)
    if len({r['pid'] for r in rows})!=len(rows):
        report['errors'].append('DUPLICATE_REGISTERED_PROCESS_GROUP')
    for row in rows:
        pgid, ticks = row['pgid'], row['start_ticks']
        try:
            active = _active_registered_group(pgid, ticks)
            if not active:
                continue
            for sig, wait_seconds in ((signal.SIGTERM, grace), (signal.SIGKILL, 0.25)):
                try:
                    os.killpg(pgid, sig)
                except ProcessLookupError:
                    break
                deadline = time.monotonic() + max(wait_seconds, 0.0)
                while time.monotonic() < deadline:
                    if not _active_registered_group(pgid, ticks):
                        break
                    time.sleep(0.02)
                if not _active_registered_group(pgid, ticks):
                    break
            survivors = _active_registered_group(pgid, ticks)
            if survivors:
                report['survivors'].append({'pgid': pgid, 'pids': survivors})
            else:
                report['groups_reaped'] += 1
        except (OSError, LiveSourceHold) as exc:
            report['errors'].append(f'GROUP_{pgid}_{type(exc).__name__}: {exc}')
    report['verified']=report['registry_present'] and not report['errors'] and not report['survivors']
    return report

# Reused from the pinned GP02C-04B source gp02c_adk_bridge.py.
class PilotIntegrationHold(RuntimeError):
    """Stop rather than claiming ADK integration on an incompatible runtime."""

def _feedback_result(result: object, feedback: dict) -> object:
    """Preserve dict vs JSON string. Never fabricate an unknown tool schema."""
    if isinstance(result, dict):
        return {**result, "gp02c_evidence": feedback}
    if isinstance(result, str):
        try:
            parsed = json.loads(result)
        except (ValueError, TypeError):
            raise PilotIntegrationHold("Agent tool returned non-JSON text; feedback mapping not certified")
        if not isinstance(parsed, dict):
            raise PilotIntegrationHold("Agent tool JSON result must be an object")
        return json.dumps({**parsed, "gp02c_evidence": feedback}, ensure_ascii=False)
    raise PilotIntegrationHold("Unsupported agent tool response type")

@dataclass(frozen=True)
class ToolBoundaryEvent:
    tool: str
    elapsed_seconds: float
    workspace_sha256: str
    revision: int
    check_id: str | None
    status: str

class ADKVisibleEvidenceBoundary:
    """Wraps existing context.create_tools tools; no extra investigation gate.

    Selected test commands are opt-in EXACT aliases, with the same mapping in
    A/B/C. After the original agent run_command, an independent trusted
    visible pytest check is executed and fully budgeted. Other commands are
    unrestricted except existing GP02B protected-path policy.

    For real Kaggle: source_root MUST resolve to the live agent sandbox's
    actual /workspace host-mounted directory. If that path cannot be verified,
    raise PilotIntegrationHold before any inference.
    """
    REQUIRED = frozenset({"submit_patch", "run_command", "edit_file", "write_file"})

    def __init__(self, controller: LiveVerificationBridge, *,
                 selected_command_aliases: Mapping[str, str],
                 required_tools: frozenset[str] | None = None,
                 event_sink: Callable[[str,dict],object] | None = None):
        self.controller = controller
        self.aliases = dict(selected_command_aliases)
        self.required_tools = required_tools if required_tools is not None else self.REQUIRED
        self.events: list[ToolBoundaryEvent] = []
        self.event_sink = event_sink
        self.submission_status = "NOT_ATTEMPTED"
        self.last_gate = None
        for alias, check in self.aliases.items():
            if not isinstance(alias, str) or not alias.strip() or '\n' in alias:
                raise ValueError("Malformed selected visible command alias")
            self.controller.ledger.manifest.get(check)
        # Never let an evaluator-only command map into the agent's visible lane.
        forbidden = re.compile(r"(?:evaluator_only|test_patch|reference_patch|protected[_-]test)", re.I)
        if any(forbidden.search(alias) for alias in self.aliases):
            raise ValueError("Protected test command not permitted")

    def _result_event(self, name: str, started: float, check_id: str | None, status: str):
        led = self.controller.ledger
        led.observe_workspace("adk_tool_event_sync")
        self.events.append(ToolBoundaryEvent(name, max(0, time.monotonic()-started),
                                             led.snapshot.sha256, led.revision,
                                             check_id, status))
        if self.event_sink is not None:
            self.event_sink('ADK_TOOL_FINISHED',{
                'tool':name,'check_id':check_id,'status':status,
                'revision':led.revision,'workspace_sha256':led.snapshot.sha256,
                'elapsed_seconds':round(time.monotonic()-started,5),
                'budget':self.controller.budget.summary()})

    def _submit(self, name: str, fn: Callable, args: tuple, kwargs: dict):
        # The final gate bills its own trusted checks. Do not bill gate elapsed
        # AGAIN as if it were the submit_patch call itself.
        started = time.monotonic()
        ledger = self.controller.ledger
        if ledger.arm == "A":
            # Baseline has no final gate. Tool call still counts once.
            row = self.controller.observe_agent_action(name, lambda: fn(*args, **kwargs))
            self.submission_status = "BASELINE_SUBMISSION_ATTEMPTED"
            self._result_event(name, started, None, self.submission_status)
            return row["result"]
        gate = self.controller.final_gate()
        self.last_gate = gate
        if not gate.accepted:
            if self.controller.budget.used_tool_calls < self.controller.budget.max_tool_calls:
                self.controller.budget.charge_tool(0.0)
            self.submission_status = "BLOCKED_" + gate.status
            self._result_event(name, started, None, self.submission_status)
            return {"status": "error", "error_type": "FreshVisibleVerificationBlocked",
                    "error_message": "Final selected visible validation was not verified",
                    "gp02c_gate_status": gate.status}
        if self.controller.budget.used_tool_calls >= self.controller.budget.max_tool_calls:
            self.submission_status = "BLOCKED_TOOL_BUDGET"
            self._result_event(name, started, None, self.submission_status)
            return {"status": "error", "error_type": "FreshVisibleVerificationBlocked",
                    "error_message": "No tool budget remains for submission",
                    "gp02c_gate_status": "UNVERIFIED_BUDGET"}
        if not self.controller.verify_delivery_identity(gate):
            self.submission_status = "BLOCKED_IDENTITY_CHANGED"
            self._result_event(name, started, None, self.submission_status)
            return {"status": "error", "error_type": "FreshVisibleVerificationBlocked",
                    "error_message": "Workspace or patch changed after final validation",
                    "gp02c_gate_status": "PATCH_OR_WORKSPACE_CHANGED"}
        # The 840s repair cutoff does NOT block a final 840--900s submission.
        # Charge the submission tool separately; no model-selected investigation
        # action is required. The external worker supervisor owns hard cancellation.
        if self.controller.deadline.remaining("final") <= 0:
            self.submission_status = "BLOCKED_ABSOLUTE_DEADLINE"
            self._result_event(name, started, None, self.submission_status)
            return {"status": "error", "error_type": "FreshVisibleVerificationBlocked",
                    "gp02c_gate_status": "UNVERIFIED_BUDGET"}
        self.controller.ledger.observe_workspace("before_submit_patch")
        submit_started = time.monotonic()
        try:
            result = fn(*args, **kwargs)
        finally:
            elapsed_submit_only = time.monotonic() - submit_started
            self.controller.ledger.observe_workspace("after_submit_patch")
            self.controller.budget.charge_tool(elapsed_submit_only)
        self.submission_status = ("SUBMITTED_GATE_VALID" if
                                  self.controller.verify_delivery_identity(gate)
                                  and not self.controller.budget.over_limit
                                  else "SUBMITTED_BUT_IDENTITY_OR_BUDGET_INVALID")
        self._result_event(name, started, None, self.submission_status)
        return result

    def _ordinary(self, name: str, fn: Callable, args: tuple, kwargs: dict):
        started = time.monotonic()
        data = self.controller.observe_agent_action(name, lambda: fn(*args, **kwargs))
        result = data["result"]
        feedback = self.controller.agent_visible_feedback(data)
        chosen_id = None
        if name == "run_command" and isinstance(kwargs.get("command"), str):
            alias = kwargs["command"].strip()
            chosen_id = self.aliases.get(alias)
            if chosen_id is None and 'rich_style_visible' in self.aliases.values():
                chosen_id = selected_visible_command(alias)
            raw = result
            if isinstance(raw, str):
                try:
                    raw = json.loads(raw)
                except ValueError:
                    raw = {}
            raw_exit = raw.get('exit_code') if isinstance(raw, dict) else None
            if chosen_id is None:
                for check in self.controller.ledger.manifest.checks:
                    if not check.check_id.startswith(('dev_', 'gp03_')) or check.check_id not in self.aliases.values():
                        continue
                    chosen_id = selected_visible_command(
                        alias, check.check_id, selector=check.test_selection,
                        allow_src_pythonpath=self.controller.ledger.task_id == 'httpx_3672')
                    if chosen_id is None and raw_exit == 0:
                        # A successful explicit whole-suite request covers the
                        # selected file. Only the independently rerun file is
                        # eligible for a receipt. Never match bare pytest.
                        for suite in ('tests', 'tests/'):
                            chosen_id = selected_visible_command(
                                alias, check.check_id, selector=suite,
                                allow_src_pythonpath=self.controller.ledger.task_id == 'httpx_3672')
                            if chosen_id is not None:
                                break
                    if chosen_id is not None:
                        break
            if chosen_id is not None and chosen_id not in self.aliases.values():
                chosen_id = None
            if chosen_id is not None:
                # Common A/B/C trusted observation: one additional qualified
                # visible check, charged to the common shared tool budget.
                receipt = self.controller._run_check(chosen_id, "agent")
                self.controller.ledger.observe_workspace("after_trusted_selected_check")
                if receipt is not None:
                    status = self.controller.ledger.status(receipt)
                else:
                    status = "UNVERIFIED_BUDGET"
                self.controller.ledger.events.append({"type": "ADK_SELECTED_VISIBLE_CHECK",
                                                       "check_id": chosen_id,
                                                       "status": status,
                                                       "receipt_id": receipt.receipt_id if receipt else None,
                                                       "original_exit_code": raw_exit,
                                                       "original_command": alias})
        self._result_event(name, started, chosen_id, "COMPLETED")
        # In B (and A), the controller is observational before submission.
        if self.controller.ledger.arm != "C" or not feedback.get("changed"):
            return result
        if (not isinstance(result, (dict, str))):
            raise PilotIntegrationHold("Unexpected ADK tool return type during C feedback")
        return _feedback_result(result, feedback)

    def wrap(self, tools: Mapping[str, Callable]) -> dict[str, Callable]:
        if not isinstance(tools, Mapping) or not self.required_tools.issubset(tools):
            raise PilotIntegrationHold("Required v2.7 agent tools unavailable in ADK registry")
        wrapped = {}
        for name, fn in tools.items():
            if not callable(fn):
                raise PilotIntegrationHold("Noncallable ADK tool")
            @functools.wraps(fn)
            def invoke(*args, _name=name, _fn=fn, **kwargs):
                if self.event_sink is not None:
                    self.event_sink('ADK_TOOL_STARTED',{'tool':_name,
                        'revision':self.controller.ledger.revision,
                        'workspace_sha256':self.controller.ledger.snapshot.sha256})
                if _name == "submit_patch":
                    return self._submit(_name, _fn, args, kwargs)
                return self._ordinary(_name, _fn, args, kwargs)
            # Python signature introspection follows __wrapped__ automatically.
            if inspect.signature(invoke) != inspect.signature(fn):
                raise PilotIntegrationHold("Callable signature not preserved")
            wrapped[name] = invoke
        return wrapped

    def attach_to_context(self, context: object) -> Callable[[], None]:
        """Reversible pilot-only insertion AFTER v2.7 existing tool policy."""
        create_tools = getattr(context, "create_tools", None)
        if not callable(create_tools):
            raise PilotIntegrationHold("Expected ADK SwegemmaContext.create_tools is unavailable")
        original = create_tools
        @functools.wraps(original)
        def create_tools_with_evidence():
            return self.wrap(original())
        context.create_tools = create_tools_with_evidence
        def restore():
            context.create_tools = original
        return restore

    def sync_model_calls(self, observed_count: int) -> None:
        """Live worker must call from model-use observer; fail on excess calls."""
        budget = self.controller.budget
        if observed_count < budget.used_model_calls:
            raise PilotIntegrationHold("Model counter went backward")
        while budget.used_model_calls < observed_count:
            budget.charge_model(0.0)
        if self.event_sink is not None:
            self.event_sink('MODEL_COUNTER_SYNC',{'model_calls':budget.used_model_calls,
                                                   'budget':budget.summary()})

    def export_audit(self) -> dict:
        return {"schema": "gp02c.adk-tool-boundary.v1", "arm": self.controller.ledger.arm,
                "events": [asdict(e) for e in self.events],
                "selected_command_aliases": dict(self.aliases),
                "submission_status": self.submission_status,
                "last_gate": asdict(self.last_gate) if self.last_gate else None,
                "budget": self.controller.budget.summary()}

PAIR_BUDGET = {"ordinary_seconds": 840, "worker_seconds": 900, "final_reserve_seconds": 60,
               "max_tool_calls": 60, "max_model_calls": 60}


class GP03ProductionFingerprinter:
    """Track implementation changes separately from the immutable test definition."""

    def __init__(self, root, production_root):
        self.root = Path(root).resolve(strict=True)
        self.production_root = production_root

    def snapshot(self):
        package = self.root / self.production_root
        if not package.is_dir() or package.resolve() != package:
            raise CPUHold("PRODUCTION_ROOT_CHANGED", "The implementation root is missing or linked")
        entries = []
        for name, kind, digest in WorkspaceFingerprinter(package).snapshot().entries:
            relative = self.production_root + name
            if kind == "L":
                raise CPUHold("PRODUCTION_LINK_HOLD", f"Unexpected implementation link {relative}")
            if is_production(relative, (self.production_root,)):
                entries.append((relative, kind, digest))
        return Snapshot(canonical_hash(entries), len(entries), tuple(entries))


def gp03_test_directory_links(root):
    links = {}
    for parent, directories, _ in os.walk(root / "tests", followlinks=False):
        for name in directories:
            path = Path(parent) / name
            if path.is_symlink():
                links[path.relative_to(root).as_posix()] = os.readlink(path)
    return links


class GP03PairedLedger(EvidenceLedger):
    def __init__(self, root, visible, *, check_manifest, adapter, **identity):
        super().__init__(root, visible, **identity)
        self.fingerprinter = GP03ProductionFingerprinter(root, check_manifest["production_root"])
        self.snapshot = self.fingerprinter.snapshot()
        self.adapter = adapter

    def _definition_matches(self, check):
        try:
            self.adapter._validate_definition(check, self.fingerprinter.root)
        except (CPUHold, OSError, RuntimeError, ValueError):
            return False
        return True


class GP03PairedAdapter(GP03PublicPytestAdapter):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.directory_links = gp03_test_directory_links(self.source_root)

    def _validate_definition(self, check, root):
        super()._validate_definition(check, root)
        if gp03_test_directory_links(root) != self.directory_links:
            raise CPUHold("VISIBLE_LINK_CHANGED", "A public test directory link differs from the baseline")


def attach_gp03_pair(*, context, root, results_root, manifest, arm, seed, run_id, environment_sha,
                     started_monotonic, baseline_ref, event_sink=None):
    """Bind B or C to the same public manifest and one fresh per-arm deadline."""
    root = Path(root).resolve(strict=True)
    if arm not in {"B", "C"} or seed != 42:
        raise CPUHold("PAIR_IDENTITY", "Expected B/C and the registered seed label")
    if manifest["environment_sha256"] != environment_sha:
        raise CPUHold("PAIR_ENVIRONMENT", "The public-check runtime differs from qualification")
    if WorkspaceFingerprinter(root).snapshot().sha256 != manifest["baseline_source_sha256"]:
        raise CPUHold("PAIR_BASELINE_SOURCE", "The initial working tree differs from the accepted baseline")
    deadline = RealDeadline(PAIR_BUDGET["ordinary_seconds"], PAIR_BUDGET["worker_seconds"],
                            started_monotonic=started_monotonic)
    adapter = GP03PairedAdapter(
        source_root=root, manifest=manifest, environment_sha256=environment_sha, deadline=deadline,
        results_root=results_root,
    )
    check = adapter.check
    adapter._validate_definition(check, root)
    visible = VisibleManifest((check,), strict=True)
    ledger = GP03PairedLedger(root, visible, check_manifest=manifest, adapter=adapter,
                             run_id=run_id, task_id=manifest["task_id"], arm=arm, seed=seed,
                             environment_sha256=environment_sha)
    budget = SharedBudget(max_wall_seconds=PAIR_BUDGET["worker_seconds"],
                          final_reserve_seconds=PAIR_BUDGET["final_reserve_seconds"],
                          max_tool_calls=PAIR_BUDGET["max_tool_calls"], max_model_calls=PAIR_BUDGET["max_model_calls"])

    def production_patch_sha():
        patch, _ = candidate_bytes(root, roots=(manifest["production_root"],), base_ref=baseline_ref)
        return hashlib.sha256(patch).hexdigest()

    controller = LiveVerificationBridge(ledger, budget, adapter, production_patch_sha)
    selector = check.test_selection
    boundary = ADKVisibleEvidenceBoundary(
        controller, selected_command_aliases={f"pytest {selector}": check.check_id,
                                              f"python -m pytest {selector}": check.check_id},
        event_sink=event_sink,
    )
    restore = boundary.attach_to_context(context)
    return boundary, restore

def load_acceptance_pins(working, explicit_path, evidence, plan):
    if explicit_path is not None:
        path = Path(explicit_path)
    else:
        path = working / evidence["filename"]
        if not path.is_file():
            matches = sorted(Path("/kaggle/input").rglob(evidence["filename"]))
            path = next((match for match in matches if sha256_file(match) == evidence["sha256"]), path)
    if not path.is_file():
        raise CPUHold("CPU_EVIDENCE_MISSING", f"Place {evidence['filename']} in /kaggle/working or mount it as an input")
    if sha256_file(path) != evidence["sha256"]:
        raise CPUHold("CPU_EVIDENCE_MISMATCH", "The qualification evidence ZIP differs from its SHA-256 pin")
    index = verify_zip(path)
    pins = {}
    with zipfile.ZipFile(path) as archive:
        report = json.loads(archive.read("GP03_CPU_Report.json"))
        if (report["run_sha256"] != evidence["qualification_run_sha256"]
                or report["notebook_recipe_sha256"] != evidence["notebook_recipe_sha256"]
                or report["tasks_sha256"] != evidence["tasks_sha256"]
                or report["gp00_split_sha256"] != evidence["gp00_split_sha256"]
                or environment_fingerprint(report["environment"]) != evidence["cpu_environment_sha256"]
                or report["environment_sha256"] != evidence["cpu_environment_sha256"]
                or report["evaluation_frozen"] or report["model_calls"] or report["protected_verifier_calls"]):
            raise CPUHold("CPU_REPORT_MISMATCH", "The qualification report disagrees with the verified public evidence")
        rows = {row["task_id"]: row for row in report["rows"]}
        for entry in plan:
            task = entry["task_id"]
            prefix = f"tasks/{task}/"
            manifest_name = prefix + "CPU_Check_Manifest.json"
            receipt_name = prefix + "Task_Receipt.json"
            result_name = prefix + "Task_Result.json"
            junit_name = prefix + "baseline/junit.xml"
            manifest = json.loads(archive.read(manifest_name))
            receipt = json.loads(archive.read(receipt_name))
            prior = json.loads(archive.read(result_name))
            expected = junit_counts(archive.read(junit_name))
            run_sha = (report["prior_evidence"]["run_sha256"] if entry["cpu_receipt_origin"] == "v1.0_retained"
                       else report["run_sha256"])
            check = gp03_check_from_manifest(manifest)
            same_identity = all(manifest[k] == entry[k] for k in (
                "task_id", "repo", "base_commit", "native_head", "native_tree", "snapshot_sha256", "baseline_outcome",
            ))
            if (not same_identity or manifest_name != entry["cpu_check_member"]
                    or index[manifest_name]["sha256"] != entry["cpu_check_sha256"]
                    or index[receipt_name]["sha256"] != entry["cpu_receipt_sha256"]
                    or receipt["task_id"] != task or receipt["run_sha256"] != run_sha
                    or receipt["files"] != {k.removeprefix(prefix): v for k, v in index.items()
                                             if k.startswith(prefix) and k != receipt_name}
                    or prior != rows[task] or prior["status"] != "CPU_READY"
                    or manifest["schema"] != "gp03.public-cpu-check.v1"
                    or manifest["environment_sha256"] != evidence["cpu_environment_sha256"]
                    or manifest["source_policy"] != "gp02c_workspace_all_files_excluding_fixed_generated_artifacts"
                    or manifest["baseline_junit_sha256"] != index[junit_name]["sha256"]
                    or manifest["expected_nodeids_sha256"] != canonical_hash(manifest["expected_nodeids"])
                    or list(check.command) != entry["public_check_argv"]
                    or check.expected_collected != entry["expected_collected"]
                    or check.expected_collected != len(manifest["expected_nodeids"])
                    or check.expected_collected != expected[0]):
                raise CPUHold("TASK_RECEIPT_MISMATCH", f"Qualification receipt or check differs from its pins for {task}")
            link_file = prefix + "Snapshot_Links.json"
            links = json.loads(archive.read(link_file)) if link_file in index else []
            pins[task] = (manifest, expected, links)
    return pins

def verify_public_acceptance(path, working, pins, plan):
    if path is None:
        path = working / GP03_ADAPTER_EVIDENCE_NAME
        if not path.is_file():
            matches = sorted(Path("/kaggle/input").rglob(GP03_ADAPTER_EVIDENCE_NAME))
            path = next((p for p in matches if sha256_file(p) == GP03_ADAPTER_EVIDENCE_SHA256), path)
    path = Path(path)
    if not path.is_file():
        raise CPUHold("ADAPTER_EVIDENCE_MISSING", f"Make {GP03_ADAPTER_EVIDENCE_NAME} available to the notebook")
    if sha256_file(path) != GP03_ADAPTER_EVIDENCE_SHA256:
        raise CPUHold("ADAPTER_EVIDENCE_MISMATCH", "Public adapter ZIP differs from the reviewed evidence")
    index = verify_zip(path)
    with zipfile.ZipFile(path) as archive:
        def read(name):
            return json.loads(archive.read(name))

        report = read("GP03_Public_Adapter_Report.json")
        profile = read("CPU_Environment.json")
        if (read("GP03_Proposed_Pair_Order.json") != {"evaluation_frozen": False, "pairs": plan}
                or report["status"] != "GP03_PUBLIC_ADAPTER_ACCEPTED"
                or report["adapter_recipe_sha256"] != ADAPTER_RECIPE_SHA256
                or report["eligible_pool_sha256"] != ELIGIBLE_POOL_SHA256
                or report["qualification_evidence_sha256"] != GP03_CPU_EVIDENCE["sha256"]
                or report["environment_sha256"] != environment_fingerprint(profile)
                or report["environment_sha256"] != GP03_CPU_EVIDENCE["cpu_environment_sha256"]
                or report["model_calls"] or report["protected_verifier_calls"] or report["held_out_agent_attempts"]
                or report["evaluation_frozen"] or report["preflight_hold"]
                or (report["planned"], report["ready"], report["holds"], report["pending"]) != (len(plan), len(plan), 0, 0)
                or [row["task_id"] for row in report["rows"]] != [entry["task_id"] for entry in plan]):
            raise CPUHold("ADAPTER_REPORT_MISMATCH", "The accepted report does not match the pinned cohort and runtime")
        for row in report["rows"]:
            task = row["task_id"]
            manifest, counts, links = pins[task]
            task_dir = f"tasks/{task}"
            check_dir = task_dir + "/checks/check_0001"
            check = read(check_dir + "/Public_Check_Receipt.json")
            phase = read(check_dir + "/pytest/command.json")
            observed_links = [{"path": link["path"], "target": link["target"]}
                              for link in links if link["kind"] == "symlink"]
            if (read(task_dir + "/Adapter_Acceptance.json") != row
                    or row["status"] != "ADAPTER_READY" or row["reason"] is not None
                    or row["outcome"] != manifest["baseline_outcome"]
                    or row["check_seconds"] > PAIR_BUDGET["final_reserve_seconds"]
                    or row["isolated_links"] != len(observed_links) or check["isolated_links"] != observed_links
                    or check["check_id"] != manifest["check"]["check_id"] or check["phase"] != "final"
                    or check["reason"] is not None or check["outcome"] != row["outcome"]
                    or check["actual_nodeids_sha256"] != manifest["expected_nodeids_sha256"]
                    or row["actual_nodeids_sha256"] != manifest["expected_nodeids_sha256"]
                    or any(check[k] != manifest["baseline_source_sha256"] for k in
                           ("source_sha256_before", "source_sha256_after", "isolated_source_sha256_after"))
                    or phase["argv"][:6] != manifest["check"]["command"] or phase["timed_out"]
                    or check["junit_sha256"] != index[check_dir + "/pytest/junit.xml"]["sha256"]
                    or junit_counts(archive.read(check_dir + "/pytest/junit.xml")) != counts):
                raise CPUHold("ADAPTER_RECEIPT_MISMATCH", f"Accepted public observation changed for {task}")
    return report


def proposed_pair_lock(plan):
    return {
        "schema": "gp03.paired-runner-lock-draft.v1", "evaluation_frozen": False,
        "public_adapter_evidence_sha256": GP03_ADAPTER_EVIDENCE_SHA256,
        "cpu_qualification_evidence_sha256": GP03_CPU_EVIDENCE["sha256"],
        "eligible_pool_sha256": ELIGIBLE_POOL_SHA256,
        "paired_wiring_recipe_sha256": GP03_PAIR_RECIPE_SHA256,
        "pair_order_sha256": canonical_hash(plan), "pairs": plan, "budget": PAIR_BUDGET,
        "planned_batches": [5, 4], "worker_wall_cap_minutes": 270, "planning_reserve_minutes": 90,
        "seed_label": 42, "effective_live_request_seed_verified": False,
        "pending": ["official agent-worker integration", "L4 runtime and serving pins", "live request seed",
                    "protected grading and paired scoring pins", "launch quota confirmation"],
    }
