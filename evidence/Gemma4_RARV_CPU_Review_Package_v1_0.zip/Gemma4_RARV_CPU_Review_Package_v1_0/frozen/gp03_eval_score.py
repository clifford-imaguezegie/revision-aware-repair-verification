"""Frozen paired analysis for independently graded GP03 repair attempts."""

from collections import defaultdict
from random import Random


BOOTSTRAP_DRAWS = 10_000
BOOTSTRAP_SEED = 20261108


def protected_endpoint(attempt, grade):
    if not attempt or attempt["status"] not in {"OBSERVED", "DEADLINE"}:
        return None
    if attempt["candidate_bytes"] == 0:
        return 0
    if (not grade or grade["attempt_id"] != attempt["attempt_id"]
            or grade["candidate_sha256"] != attempt["candidate_sha256"]):
        return None
    if grade.get("candidate_disposition") == "NONAPPLICABLE" and grade["protected_grade"] == "NOT_RUN":
        return 0
    return {"PASS": 1, "FAIL": 0}.get(grade["protected_grade"])


def paired_results(pairs, attempts, grades):
    """Use a single accepted record per arm. Missing and infrastructure grades stay unresolved."""
    grade_by_attempt = {row["attempt_id"]: row for row in grades}
    by_arm = {(row["task_id"], row["arm"]): row for row in attempts}
    if len(grade_by_attempt) != len(grades) or len(by_arm) != len(attempts):
        raise ValueError("Duplicate attempt or grade in the accepted analysis input")
    allowed = {(row["task_id"], arm) for row in pairs for arm in ("B", "C")}
    if set(by_arm) - allowed or set(grade_by_attempt) - {row["attempt_id"] for row in attempts}:
        raise ValueError("Analysis input contains an assignment outside the frozen cohort")
    strata = defaultdict(list)
    paired_counts = dict(both_pass=0, b_only=0, c_only=0, neither_pass=0)
    table = []
    lower = upper = 0
    for pair in pairs:
        task = pair["task_id"]
        arms = {}
        for arm in ("B", "C"):
            attempt = by_arm.get((task, arm))
            grade = grade_by_attempt.get(attempt["attempt_id"]) if attempt else None
            arms[arm] = {"protected_outcome": protected_endpoint(attempt, grade),
                         "protected_grade": grade["protected_grade"] if grade else "NOT_RUN",
                         "attempt_status": attempt["status"] if attempt else "MISSING",
                         "verified_delivery": bool(grade and grade.get("verified_delivery")),
                         "attempt_id": attempt["attempt_id"] if attempt else None,
                         "worker_seconds": attempt.get("elapsed_seconds") if attempt else None,
                         "model_calls": attempt.get("model_calls") if attempt else None,
                         "tool_calls": attempt.get("tool_calls") if attempt else None,
                         "trusted_checks": attempt.get("trusted_checks") if attempt else None,
                         "proactive_rechecks": attempt.get("proactive_rechecks") if attempt else None,
                         "natural_exposures": attempt.get("natural_exposures") if attempt else None,
                         "observed_regressions": attempt.get("observed_regressions") if attempt else None}
        b, c = (arms[a]["protected_outcome"] for a in ("B", "C"))
        lower += (0 if c is None else c) - (1 if b is None else b)
        upper += (1 if c is None else c) - (0 if b is None else b)
        if b is not None and c is not None:
            paired_counts[{(1, 1): "both_pass", (1, 0): "b_only", (0, 1): "c_only", (0, 0): "neither_pass"}[(b, c)]] += 1
            strata[pair["repo"]].append(c - b)
        table.append({"task_id": task, "repo": pair["repo"], "arm_order": pair["arm_order"], **arms})
    assigned = len(pairs)
    observed = sum(paired_counts.values())
    difference = interval = discordance_upper = None
    if observed:
        difference = (paired_counts["c_only"] - paired_counts["b_only"]) / observed
        rng = Random(BOOTSTRAP_SEED)
        groups = [strata[key] for key in sorted(strata)]
        draws = sorted(sum(sum(rng.choices(group, k=len(group))) for group in groups) / observed for _ in range(BOOTSTRAP_DRAWS))
        def quantile(q):
            at = q * (len(draws) - 1)
            lo = int(at)
            return draws[lo] + (at - lo) * (draws[min(lo + 1, len(draws) - 1)] - draws[lo])
        interval = [quantile(.025), quantile(.975)]
        if paired_counts["b_only"] + paired_counts["c_only"] == 0:
            discordance_upper = 1 - .05 ** (1 / observed)
    exposure = {}
    for arm in ("B", "C"):
        values = [row[arm]["natural_exposures"] for row in table if row[arm]["natural_exposures"] is not None]
        exposure[arm] = {"assigned": assigned, "observable_attempts": len(values), "arms_with_exposure": sum(v > 0 for v in values),
                         "qualifying_pass_edit_events": sum(values)}
    return {"assigned_pairs": assigned, "scored_pairs": observed, "unresolved_pairs": assigned - observed,
            "paired_counts": paired_counts, "protected_success_difference_c_minus_b": difference,
            "paired_repo_stratified_bootstrap_95": interval, "bootstrap_draws": BOOTSTRAP_DRAWS, "bootstrap_seed": BOOTSTRAP_SEED,
            "assigned_pair_bounds": [lower / assigned, upper / assigned] if assigned else None,
            "zero_discordance_upper_95": discordance_upper, "natural_exposure": exposure, "rows": table}
