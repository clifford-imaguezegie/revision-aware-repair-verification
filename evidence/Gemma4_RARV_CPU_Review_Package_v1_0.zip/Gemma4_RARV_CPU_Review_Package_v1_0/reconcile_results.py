"""Reconstruct the study outcomes from sealed attempt records and CPU verdicts."""

import argparse
from contextlib import ExitStack
from hashlib import sha256
import json
from pathlib import Path
import re
from zipfile import ZipFile

from review_evidence import (
    FREEZE_NAME, FREEZE_SHA256, bundled_member, checked_member, digest_file,
    import_frozen, provenance, require, source_freeze,
)

EMPTY_PATCH = sha256(b"").hexdigest()


def load_records(pins, archives, runtime, stack):
    records = {}
    zips = {}
    indexes = {}
    for label, source in pins["archives"].items():
        if archives is not None:
            path = archives / source["filename"]
            require(digest_file(path) == source["sha256"], f"Original ZIP SHA-256 mismatch: {path.name}")
            indexes[label] = runtime.verify_zip(path)
            zips[label] = stack.enter_context(ZipFile(path))
        for member, pin in source["members"].items():
            bundled = bundled_member(pins, label, member)
            if archives is not None:
                require(indexes[label][member] == pin, f"Sealed member index mismatch: {label}/{member}")
                raw = checked_member(zips[label].read(member), pin, f"{label}/{member}")
                require(raw == bundled, f"Original and bundled member disagree: {label}/{member}")
            else:
                raw = bundled
            records[label, member] = json.loads(raw)
    return records, zips


def validate_attempts(pairs, attempts, execution_sha, *, condition_field=False):
    expected = [(p["task_id"], arm) for p in pairs for arm in p["arm_order"]]
    actual = [(a["task_id"], a["arm"]) for a in attempts]
    require(actual == expected and len(set(actual)) == len(actual), "Unexpected or duplicate arm assignment")
    by_task = {p["task_id"]: p for p in pairs}
    for row in attempts:
        task, arm = row["task_id"], row["arm"]
        require(row["attempt_id"] == f"{execution_sha[:12]}_{task}_{arm}_01"
                and row["freeze_sha256"] == execution_sha and row["attempt_number"] == 1,
                f"Unmatched attempt identity: {task}/{arm}")
        require(row["repo"] == by_task[task]["repo"] and row["status"] in {"OBSERVED", "DEADLINE"}
                and row["cleanup_verified"] is True, f"Unaccepted attempt: {task}/{arm}")
        if condition_field:
            require(row["condition"] == by_task[task]["condition"], f"Condition mismatch: {task}/{arm}")
        size = row["candidate_bytes"]
        digest = row["candidate_sha256"]
        require(type(size) is int and size >= 0 and re.fullmatch(r"[0-9a-f]{64}", digest)
                and (size == 0) == (digest == EMPTY_PATCH), f"Invalid production patch identity: {task}/{arm}")


def grade_join(attempts, grades):
    by_id = {g["attempt_id"]: g for g in grades}
    nonempty = {a["attempt_id"] for a in attempts if a["candidate_bytes"]}
    require(len(by_id) == len(grades) and set(by_id) == nonempty, "Duplicate, missing or extra protected verdict")
    for attempt in attempts:
        grade = by_id.get(attempt["attempt_id"])
        if grade is None:
            continue
        for key in ("task_id", "arm", "candidate_sha256"):
            require(grade[key] == attempt[key], f"Grade identity mismatch: {attempt['attempt_id']} {key}")
        status, counts = grade["protected_grade"], grade["protected_counts"]
        require(status in {"PASS", "FAIL"} and grade["patch_identity"]["applicable"] is True,
                "Expected an applicable, resolved protected verdict")
        require(counts["errors"] == 0 and counts["tests"] == sum(counts[k] for k in ("passed", "failures", "skipped", "errors"))
                and (counts["failures"] == 0) == (status == "PASS")
                and grade["evaluator_exit_code"] == (0 if status == "PASS" else 1),
                f"Protected test counts or exit status disagree: {attempt['attempt_id']}")
        gate_matches = grade["patch_identity"]["gate_identity_matches"]
        require(not gate_matches or attempt["submission_status"] == "SUBMITTED_GATE_VALID",
                f"Verified gate did not accept the attempt: {attempt['attempt_id']}")
        require(grade["verified_delivery"] == (status == "PASS" and gate_matches), "Delivery verdict mismatch")
    return by_id


def verify_original_attempt(z, attempt, grade):
    """Audit the actual patch bytes and the saved final gate/ledger identity."""
    base = f"attempts/{attempt['task_id']}/{attempt['arm']}/attempt_01/"
    require(json.loads(z.read(base + "Attempt_Result.json")) == attempt, "Sealed attempt member disagrees")
    patch_name = base + "Production_Candidate.patch"
    patch = z.read(patch_name) if patch_name in z.namelist() else b""
    require(len(patch) == attempt["candidate_bytes"] and sha256(patch).hexdigest() == attempt["candidate_sha256"],
            f"Captured patch bytes mismatch: {attempt['attempt_id']}")
    if grade is None:
        return
    cp = json.loads(z.read(base + "artifacts/capture/Latest_Checkpoint.json"))
    require(cp["candidate"]["sha256"] == attempt["candidate_sha256"], "Checkpoint candidate digest mismatch")
    audit, ledger = cp["audit"], cp["ledger"]
    gate = audit.get("last_gate") or {}
    identity = grade["patch_identity"]
    gate_matches = bool(
        identity["official_return_equivalent"]
        and audit.get("submission_status") == "SUBMITTED_GATE_VALID"
        and gate.get("accepted") is True
        and gate.get("accepted_patch_sha256") == attempt["candidate_sha256"]
        and ledger.get("workspace_sha256")
        and gate.get("accepted_workspace_sha256") == ledger["workspace_sha256"]
        and type(ledger.get("workspace_revision")) is int
        and gate.get("accepted_revision") == ledger["workspace_revision"]
    )
    require(gate_matches == identity["gate_identity_matches"], f"Checkpoint gate identity mismatch: {attempt['attempt_id']}")


def outcome_summary(result):
    return {
        "pairs_assigned": result["assigned_pairs"],
        "pairs_scored": result["scored_pairs"],
        "pairs_held": result["unresolved_pairs"],
        "protected_passes": {arm: sum(r[arm]["protected_outcome"] == 1 for r in result["rows"]) for arm in ("B", "C")},
        "verified_deliveries": {arm: sum(r[arm]["verified_delivery"] for r in result["rows"]) for arm in ("B", "C")},
    }


def compare_saved_row(rebuilt, archived, task):
    for arm in ("B", "C"):
        for key in ("protected_grade", "protected_outcome", "verified_delivery", "attempt_status", "model_calls"):
            require(rebuilt[arm][key] == archived[arm][key], f"Reconstructed outcome mismatch: {task}/{arm}/{key}")


def reconstruct(archives=None):
    pins = provenance()
    freeze = source_freeze(pins)
    score = import_frozen("gp03_eval_score", freeze["source_sha256"]["gp03_eval_score.py"])
    runtime = import_frozen("gp03_public_runtime", freeze["source_sha256"]["gp03_public_runtime.py"]) if archives else None
    with ExitStack() as stack:
        data, zips = load_records(pins, archives, runtime, stack)
        wave_labels = ("gp03_wave1", "gp03_wave2")
        waves = [data[label, "Wave_Report.json"] for label in wave_labels]
        gp03 = [row for wave in waves for row in wave["attempts"]]
        grade03 = data["gp03_grade", "Grade_Report.json"]
        grade03_rows = data["gp03_grade", "Protected_Grades.json"]
        require(all(wave["freeze_sha256"] == FREEZE_SHA256 and wave["wave"] == i for i, wave in enumerate(waves, 1))
                and grade03["freeze_sha256"] == FREEZE_SHA256, "GP03 source freeze or wave mismatch")
        require(grade03["input_zips"] == [
            {"name": pins["archives"][label]["filename"], "sha256": pins["archives"][label]["sha256"]}
            for label in wave_labels
        ], "GP03 grader input archive mismatch")
        validate_attempts(freeze["pairs"], gp03, FREEZE_SHA256)
        join03 = grade_join(gp03, grade03_rows)
        primary = score.paired_results(freeze["pairs"], gp03, grade03_rows)
        require(primary == data["gp03_grade", "Paired_Results.json"], "Reconstructed GP03 results disagree with the final score")

        gpu04 = data["gp04_gpu", "GP04_GPU_Report.json"]
        grade04 = data["gp04_grade", "GP04_Grade_Report.json"]
        grade04_rows = data["gp04_grade", "GP04_Protected_Grades.json"]
        gpu05 = data["gp05_gpu", "GP05_GPU_Report.json"]
        grade05 = data["gp05_grade", "GP05_Grade_Report.json"]
        grade05_rows = data["gp05_grade", "GP05_Protected_Grades.json"]
        for label, run, graded in (("gp04_gpu", gpu04, grade04), ("gp05_gpu", gpu05, grade05)):
            require(run["parent_freeze_sha256"] == FREEZE_SHA256 and
                    graded["evaluation_zip_sha256"] == pins["archives"][label]["sha256"] and
                    graded["preflight_zip_sha256"] == run["preflight_zip_sha256"] and
                    graded["protocol_sha256"] == run["protocol_sha256"],
                    f"GPU and CPU handoff mismatch: {label}")
        require(grade05["assignment"] == gpu05["assignment"], "GP05 assignment mismatch")
        validate_attempts(gpu04["assigned_pairs"], gpu04["attempts"], gpu04["execution_sha256"], condition_field=True)
        validate_attempts([gpu05["assignment"]], gpu05["attempts"], gpu05["execution_sha256"])
        join04 = grade_join(gpu04["attempts"], grade04_rows)
        join05 = grade_join(gpu05["attempts"], grade05_rows)
        group04 = {}
        for condition in ("AUTONOMOUS", "CONTROLLED"):
            pairs = [row for row in gpu04["assigned_pairs"] if row["condition"] == condition]
            attempts = [a for a in gpu04["attempts"] if a["condition"] == condition]
            grades = [join04[a["attempt_id"]] for a in attempts if a["attempt_id"] in join04]
            result = score.paired_results(pairs, attempts, grades)
            saved = {row["task_id"]: row for row in grade04["rounds"][condition]}
            require(set(saved) == {row["task_id"] for row in result["rows"]}, f"GP04 {condition} cohort mismatch")
            for row in result["rows"]:
                compare_saved_row(row, saved[row["task_id"]], row["task_id"])
            group04[condition] = result
        extra = score.paired_results([gpu05["assignment"]], gpu05["attempts"], grade05_rows)
        compare_saved_row(extra["rows"][0], grade05["outcomes"], gpu05["assignment"]["task_id"])
        if archives is not None:
            for label, attempts, grades in (
                ("gp03_wave1", waves[0]["attempts"], join03),
                ("gp03_wave2", waves[1]["attempts"], join03),
                ("gp04_gpu", gpu04["attempts"], join04),
                ("gp05_gpu", gpu05["attempts"], join05),
            ):
                for attempt in attempts:
                    verify_original_attempt(zips[label], attempt, grades.get(attempt["attempt_id"]))

    autonomous = gp03 + [a for a in gpu04["attempts"] if a["condition"] == "AUTONOMOUS"] + gpu05["attempts"]
    controlled = [a for a in gpu04["attempts"] if a["condition"] == "CONTROLLED"]
    cohort_results = {
        "GP03_primary": outcome_summary(primary),
        "GP04_autonomous": outcome_summary(group04["AUTONOMOUS"]),
        "GP04_controlled": outcome_summary(group04["CONTROLLED"]),
        "GP05_autonomous": outcome_summary(extra),
    }
    require(sum(x["pairs_held"] for x in cohort_results.values()) == 0, "One or more study pairs remain held")
    require(sum(x["pairs_scored"] for key, x in cohort_results.items() if key != "GP04_controlled")
            == grade05["autonomous_scored_pairs_in_study"], "Autonomous denominator mismatch")
    return {
        "schema": "rarv.archive-derived-results.v1",
        "status": "PASS",
        "input_mode": "original_sealed_zips" if archives else "bundled_original_json_members",
        "source_archive_digests": {label: record["sha256"] for label, record in pins["archives"].items()},
        "verified_source_members": len(data),
        "verified_original_zip_count": len(zips),
        "verified_original_patch_records": len(autonomous) + len(controlled) if archives else 0,
        "cohorts": cohort_results,
        "GP03_primary_inference": {k: primary[k] for k in (
            "paired_counts", "protected_success_difference_c_minus_b", "paired_repo_stratified_bootstrap_95",
            "bootstrap_draws", "bootstrap_seed", "assigned_pair_bounds")},
        "autonomous_runs": len(autonomous),
        "controlled_runs": len(controlled),
        "qualifying_autonomous_pass_to_edit_events": sum(a["natural_exposures"] for a in autonomous),
        "autonomous_proactive_rechecks": sum(a["proactive_rechecks"] for a in autonomous),
        "controlled_detections": {
            a["task_id"]: a["controlled"]["edit_to_detection_seconds"]
            for a in controlled if a["arm"] == "C" and a["controlled"]["trusted_failure_observed"]
        },
        "GP05_protected_counts": {g["arm"]: g["protected_counts"] for g in grade05_rows},
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archives", type=Path, help="Optional directory containing the seven original sealed ZIPs")
    parser.add_argument("--output", type=Path, help="Write the reconstructed result JSON")
    options = parser.parse_args()
    result = reconstruct(options.archives)
    content = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if options.output:
        with options.output.open("x", encoding="utf-8") as f:
            f.write(content)
    print(content, end="")
