"""Run the real frozen GP03 controller, trusted pytest adapter and gate on CPU."""

import argparse
import json
from pathlib import Path
import platform
import sys

from review_evidence import digest_file, import_frozen, provenance, require, source_freeze


def replay(output):
    pins = provenance()
    freeze = source_freeze(pins)
    runtime = import_frozen("gp03_public_runtime", freeze["source_sha256"]["gp03_public_runtime.py"])
    fixture = import_frozen("gp03_cpu_fixture", pins["fixture_source"]["module_sha256"])
    environment = runtime.environment_profile()
    require(sys.version_info[:2] == (3, 12) and environment["pytest_version"] == "8.4.2",
            "Use Python 3.12 and the pinned offline pytest environment")
    fingerprint = runtime.environment_fingerprint(environment)
    output.mkdir(parents=True, exist_ok=False)
    arms = fixture.replay_gp03_fixture(output / "fixture", fingerprint)
    for arm in arms:
        receipts = list((output / "fixture" / arm["arm"] / "checks").rglob("junit.xml"))
        require(len(receipts) == arm["trusted_tests"] == 3, "Expected three executed trusted pytest receipts per arm")
    report = {
        "schema": "rarv.actual-controller-cpu-replay.v1",
        "status": "PASS",
        "scope": "Scripted tool requests through the frozen controller, adapter and gate on a synthetic Git checkout",
        "model_calls": 0,
        "python": platform.python_version(),
        "pytest": environment["pytest_version"],
        "environment_sha256": fingerprint,
        "gp03_public_runtime_sha256": digest_file(Path(runtime.__file__)),
        "fixture_source": pins["fixture_source"],
        "arms": arms,
    }
    runtime.write_json(output / "Replay_Report.json", report)
    print("PASS | actual controller and trusted pytest | B STALE, C CURRENT_FAIL | both gates block and restore")
    print(f"Trusted pytest checks 6 | model calls 0 | Report {output / 'Replay_Report.json'}")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("replay_output"), help="New output directory")
    replay(parser.parse_args().output.resolve())
