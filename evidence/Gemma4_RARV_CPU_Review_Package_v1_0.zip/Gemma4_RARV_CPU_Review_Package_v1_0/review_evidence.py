"""Read the pinned evidence inventory and the exact frozen Python modules."""

from hashlib import file_digest, sha256
import importlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
FREEZE_NAME = "GP03_Evaluation_Freeze_v1_1.json"
FREEZE_SHA256 = "28b958752eaca3034eaed5d05ce1069f0f356681ca7c731a825e93a44e5268d4"
PROVENANCE_SHA256 = "48a340c62171e5f07fd557dd25375c44e29f344b31aa6de2ed0788d0915c0760"


def digest_file(path):
    with Path(path).open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def provenance():
    path = ROOT / "evidence" / "Archive_Provenance.json"
    require(digest_file(path) == PROVENANCE_SHA256, "Evidence provenance SHA-256 mismatch")
    record = json.loads(path.read_bytes())
    require(record["schema"] == "rarv.review-evidence.v1" and record["gp03_freeze_sha256"] == FREEZE_SHA256,
            "Evidence provenance has the wrong schema or freeze")
    return record


def checked_member(data, pin, name):
    require((len(data), sha256(data).hexdigest()) == (pin["bytes"], pin["sha256"]), f"Evidence member mismatch: {name}")
    return data


def bundled_member(pins, label, name):
    path = ROOT / "evidence" / label / name
    return checked_member(path.read_bytes(), pins["archives"][label]["members"][name], f"{label}/{name}")


def import_frozen(name, digest):
    path = ROOT / "frozen" / f"{name}.py"
    require(digest_file(path) == digest, f"Frozen source hash mismatch: {path.name}")
    sys.path.insert(0, str(path.parent))
    module = importlib.import_module(name)
    require(Path(module.__file__).resolve() == path, f"Unexpected import origin: {name}")
    return module


def source_freeze(pins):
    raw = bundled_member(pins, "gp03_wave1", FREEZE_NAME)
    require(sha256(raw).hexdigest() == FREEZE_SHA256, "Frozen GP03 protocol hash mismatch")
    return json.loads(raw)
